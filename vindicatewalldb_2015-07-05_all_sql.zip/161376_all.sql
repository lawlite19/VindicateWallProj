﻿SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS  `t_attend`;
CREATE TABLE `t_attend` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `LastAttend` date DEFAULT NULL COMMENT '最后一次签到时间',
  `Score` int(20) DEFAULT NULL COMMENT '得到的经验分数',
  `AttendCount` int(20) DEFAULT NULL COMMENT '签到次数',
  `UserId` bigint(20) DEFAULT NULL COMMENT '外键--用户编号',
  PRIMARY KEY (`Id`),
  KEY `attend_userId` (`UserId`),
  CONSTRAINT `attend_userId` FOREIGN KEY (`UserId`) REFERENCES `t_user` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

insert into `t_attend`(`Id`,`LastAttend`,`Score`,`AttendCount`,`UserId`) values
('1','2015-07-05','1800','90','1'),
('2','2015-03-03','0','0','6'),
('3','2015-03-08','0','0','13'),
('4','2015-05-09','220','11','14'),
('5',null,'0','0','15'),
('6',null,'0','0','16'),
('7',null,'0','0','17'),
('11','2015-03-13','20','1','21'),
('12','2015-03-13','20','1','22'),
('13','2015-03-13','20','1','23'),
('14','2015-03-13','20','1','25'),
('15',null,'0','0','24'),
('16','2015-03-22','100','5','26'),
('17','2015-04-01','140','7','27'),
('18','2015-03-17','20','1','28'),
('19','2015-03-19','20','1','29'),
('20','2015-04-20','60','3','30'),
('21','2015-04-13','20','1','31'),
('22','2015-04-16','20','1','32'),
('23',null,'0','0','33'),
('24','2015-04-28','20','1','34'),
('25','2015-05-02','20','1','35'),
('26','2015-05-04','20','1','36'),
('27','2015-05-07','20','1','37'),
('28','2015-06-07','80','4','38'),
('29',null,'0','0','39'),
('30',null,'0','0','40'),
('31','2015-05-19','20','1','41'),
('32',null,'0','0','42'),
('33',null,'0','0','43'),
('34',null,'0','0','44'),
('35',null,'0','0','45'),
('36',null,'0','0','46'),
('37',null,'0','0','47'),
('38',null,'0','0','48'),
('39','2015-05-29','20','1','49'),
('40','2015-05-30','20','1','50'),
('41','2015-06-06','20','1','51'),
('42',null,'0','0','52'),
('43',null,'0','0','53'),
('44','2015-06-24','20','1','54'),
('45','2015-07-03','20','1','55');
DROP TABLE IF EXISTS  `t_dailyvindicate`;
CREATE TABLE `t_dailyvindicate` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `Vindicator` varchar(30) DEFAULT NULL COMMENT '表白者',
  `BoyName` varchar(30) DEFAULT NULL COMMENT '男生姓名',
  `GirlName` varchar(30) DEFAULT NULL COMMENT '女生姓名',
  `Content` text COMMENT '内容',
  `Comments` varchar(100) DEFAULT NULL COMMENT '一行注释',
  `ReleaseDate` date DEFAULT NULL COMMENT '发布日期',
  `Year` varchar(20) DEFAULT NULL COMMENT '在一起--年',
  `Month` varchar(20) DEFAULT NULL COMMENT '在一起--月',
  `Day` varchar(20) DEFAULT NULL COMMENT '在一起--天',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;

insert into `t_dailyvindicate`(`Id`,`Vindicator`,`BoyName`,`GirlName`,`Content`,`Comments`,`ReleaseDate`,`Year`,`Month`,`Day`) values
('1','王先生','王先生','司云轩','<span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;">曾以为我会忘了你，象忘记一颗夏夜的星。<br />
以为我会恨你发誓不再提起你，然而一切只是自欺欺人。<br />
曾经因为你而爱上这个网络，海誓山盟相邀共赴红尘。<br />
到最后你终不肯走进我的生活，每次都是惊鸿一瞥然后人间蒸发。<br />
如此这般循环往复了三年，我终在佛祖前发下重誓：此生永不复见。</span>','喜欢你，没道理','2015-03-09','2014','2','2'),
('2','','王童鞋','莫失莫忘','<span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;">曾经以为，我会是你今生最美的遇见，<br />
会是你此生最美的霓裳，最后的风景。<br />
走过花开花落，灿烂却没有结果。<br />
曾经的伴君天涯终不悔，如今的浓浓相思曲空赋;曾 经的平生至爱我一人，<br />
如今的天涯从此各西东;曾经的此生但为君前醉，<br />
如今的望断天涯何处寻？<br />
原来再见初见时的惊艳时光，<br />
只不过是你一场有口无心的承诺。</span>','我知道 我一直有双隐形的翅膀','2015-03-10','','',''),
('4','李先生','王女士','baby','<span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;">紫陌红尘，蓦然回首。<br />
多少的春花秋月;多少的逝水沉香;多少的海誓山盟，如沿途的风景花开花谢。<br />
人世间的情缘触痛了多少无言的感慨，情深缘浅的风吹散了多 少相聚离散。<br />
花开是有情，花落是无意。<br />
来者是萍水相逢，去者是江湖相忘。<br />
缘起时，我在人群中看到你。缘灭时，你消失在人群中。</span>','love you  forever','2015-03-11','2014','1','1'),
('5','司云轩','司云轩','小白兔','听见，冬天的离开<br />
我在某年某月，醒过来<br />
我想，我等，我期待<br />
未来却不能理智安排<br />
阴天，傍晚，车窗外<br />
未来有一个人在等待<br />
向左，向右，向前看<br />
爱要拐几个弯才来<br />
我遇见谁，会有怎样的对白<br />
我等的人，他在多远的未来<br />
我听见风来自地铁和人海<br />
我排着队，拿着爱的号码牌','遇见你是我最美的意外','2015-03-12','2014','2','24'),
('6','某某某','某某某','小小小','<span style="color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;">尘缘如梦</span><br style="clear: both; color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;" /><span style="color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;">几番起伏总不平</span><br style="clear: both; color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;" /><span style="color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;">到如今都成烟云</span><br style="clear: both; color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;" /><span style="color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;">情也成空</span><br style="clear: both; color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;" /><span style="color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;">宛如挥手袖底风</span><br style="clear: both; color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;" /><span style="color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;">幽幽一缕香</span><br style="clear: both; color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;" /><span style="color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;">飘在深深旧梦中</span><br style="clear: both; color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;" /><span style="color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;">繁华落尽</span><br style="clear: both; color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;" /><span style="color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;">一身憔悴在风里</span><br style="clear: both; color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;" /><span style="color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;">回头时无情也无雨</span><br style="clear: both; color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;" /><span style="color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;">明月小楼</span><br style="clear: both; color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;" /><span style="color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;">孤独无人诉情衷</span><br style="clear: both; color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;" /><span style="color: rgb(51, 51, 51); font-family: Arial; line-height: 20px; white-space: normal;">人间有我残梦未醒。</span>
','love you  forever','2015-03-13','','',''),
('7','王先僧','王先僧','花花花','看着飞舞的尘埃 掉下来<br />
没人发现它存在<br />
多自由自在<br />
......<br />
可世界都爱热热闹闹<br />
容不下 我百无聊赖<br />
不应该 一个人 发呆<br />
......<br />
只有我 守着安静的沙漠<br />
等待着花开<br />
......<br />
只有我 看着别人的快乐<br />
竟然会感慨<br />
......<br />
就让我 听着天大的道理<br />
不愿意明白<br />
......<br />
有什么 是应该 不应该。 <br type="_moz" />','随意点','2015-03-14','2013','6','6'),
('8','王勇智先僧','王勇智','大白兔','<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">多想要找到一丝挣扎在你脸上，</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">可是你美得冷得淡得像月亮，</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">等着你的那辆车 灯闪一下，</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">像催你草草断了我们的过往。<br />
...................<br />
</span><span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">约好要每年回到初拥吻的地方，</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">划一个记号写下相恋的感想，</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">等明年我剩一个人 坐在堤防，</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">改唱首什么歌来纪念爱的傻。</span>','萌萌哒，呵呵哒','2015-03-16','2014','1','1'),
('9','王勇智','王勇智先僧','修寒','每个人 都想快乐，<br />
有多少人 可以拥有，<br />
人海中 你遇过谁，<br />
那个人 你一定没有忘记<br />
有人说 要爱自己，<br />
往事不值得 再回味。<br />
.............<br />
还是会 想起从前，<br />
一个人在夜里 偷偷流泪，<br />
花<a class="inner-link decor-none" href="http://www.baidu.com/s?wd=%E8%8A%B1%E4%B8%96%E7%95%8C&amp;hl_tag=textlink&amp;tn=SE_hldp01350_v6v6zkg6" target="_blank" rel="nofollow" data-word="4" log="pos:innerLink" style="color: rgb(45, 100, 179); text-decoration: none;">花世界</a> <a class="inner-link decor-none" href="http://www.baidu.com/s?wd=%E8%8A%B1%E5%BC%80%E8%8A%B1%E8%B0%A2&amp;hl_tag=textlink&amp;tn=SE_hldp01350_v6v6zkg6" target="_blank" rel="nofollow" data-word="1" log="pos:innerLink" style="color: rgb(45, 100, 179); text-decoration: none;">花开花谢</a>，<br />
不用我开口 你都能感觉，<br />
人来人往 <a class="inner-link decor-none" href="http://www.baidu.com/s?wd=%E8%BF%87%E5%BE%80%E4%BA%91%E7%83%9F&amp;hl_tag=textlink&amp;tn=SE_hldp01350_v6v6zkg6" target="_blank" rel="nofollow" data-word="0" log="pos:innerLink" style="color: rgb(45, 100, 179); text-decoration: none;">过往云烟</a>，<br />
只要我受委屈 你都在我身边，<br />
我想说 <a class="inner-link decor-none" href="http://www.baidu.com/s?wd=%E6%9C%89%E4%BD%A0%E7%9C%9F%E5%A5%BD&amp;hl_tag=textlink&amp;tn=SE_hldp01350_v6v6zkg6" target="_blank" rel="nofollow" data-word="2" log="pos:innerLink" style="color: rgb(45, 100, 179); text-decoration: none;">有你真好</a>，<br />
有个人 可以拥抱，悲伤有 快乐有。<br />
<br />
<br />
<br />
<br type="_moz" />','哈哈，八戒','2015-03-17','','',''),
('10','王先僧','王先僧','大白兔','<span style="color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;">就让我轻轻为你&nbsp;</span><br style="outline: none; color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;">讲一个枕边故事&nbsp;</span><br style="outline: none; color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;">从前有个长发公主&nbsp;</span><br style="outline: none; color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;">悄悄爱上一只青蛙&nbsp;</span><br style="outline: none; color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;">青蛙每天都为他唱歌&nbsp;</span><br style="outline: none; color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;">国王皇后都反对他&nbsp;</span><br style="outline: none; color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;">但是公主说他是我心上人&nbsp;</span><br style="outline: none; color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;">我不能就这样和他道别&nbsp;</span><br style="outline: none; color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;">谁知道 小青蛙 变成王子&nbsp;</span><br style="outline: none; color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;">带着他的公主 逃离皇宫 喔...&nbsp;</span><br style="outline: none; color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;">私奔到一个 没人打扰的地方&nbsp;</span><br style="outline: none; color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;">从此后两个人幸福的在一起&nbsp;</span><br style="outline: none; color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft YaHei\', Arial, Tahoma, \'hiragino sans gb\', Helvetica; font-size: 14px; line-height: 22.3999996185303px;">这是她和她的童话<br />
<br type="_moz" />
</span>','love you  forever','2015-03-18','2014','11','10'),
('11','馨予溪','小兔子','馨予溪','<br />
我们说好绝不放开相互牵着的手，<br />
我们说好下个永恒里面再碰头，<br />
因此，我来实现这个承诺了，<br />
你来了吗？','我一直在等','2015-03-19','2012','12','12'),
('12','王勇智','王勇智','等待','<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">背靠着背 坐在地毯上</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">听听音乐 聊聊愿望</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">你希望我越来越温柔</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">我希望你放我在心上</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">你说想送我个浪漫的梦想</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">谢谢我带你找到天堂</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">哪怕用一辈子才能完成</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">只要我讲你就记住不忘</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">我能想到最浪漫的事</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">就是和你一起慢慢变老</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">一路上收藏点点滴滴的欢笑</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">留到以后 坐着摇椅 慢慢聊</span>','一切都是最好的安排','2015-03-20','2013','2','24'),
('13','几多愁先生','几多愁','兔兔','我不要你说我爱你，<br />
我想你说我们在一起。<br />
我不相信爱情，<br />
但我相信你，<br />
你愿意相信我嘛？<br />
&mdash;&mdash;&mdash;&mdash;几多愁先生<br />
<br />
<div>&nbsp;</div>','喜欢你，没道理','2015-03-21','2015','1','1'),
('14','雨熙','','雨熙','<pre id="recommend-content-1463786207" accuse="aContent" class="recommend-text mb-10" style="margin-top: 0px; margin-bottom: 10px; padding: 0px; font-family: arial, \'courier new\', courier, 宋体, monospace; white-space: pre-wrap; word-wrap: break-word; color: rgb(51, 51, 51); font-size: 14px; line-height: 24px; background-color: rgb(241, 254, 221);"><span style="font-size: 12px;"><span style="font-family: 宋体;">你的模样，  从来不需要想起，  永远也不会忘记。 </span></span></pre>','只因你一直在我心里','2015-03-22','','',''),
('15','王勇智','王先生','兔兔','太平山顶的星星没有你的眼睛明亮，<br />
维多利亚港湾的灯光没有你的笑容灿烂，<br />
知道吗?<br />
此时此刻我多么想你啊!<br />','永远爱你','2015-03-23','2015','1','1'),
('16','梦云','欧巴','梦云','<span style="font-size: 16px;"><span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\'; line-height: 25.2000007629395px;">桃花盛开一朵朵，<br />
春雨带着情滴落，<br />
轻轻将我心意说，<br />
离开你我没法活。<br />
难忘你的小酒窝，<br />
对你痴心爱恋多，<br />
只想将你双手握，<br />
共享幸福好生活!<br />
</span></span><span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\'; font-size: 14px; line-height: 25.2000007629395px;"><br type="_moz" />
</span>','爱你的新永不变','2015-03-24','2014','12','1'),
('17','王勇智','王勇智','兔纸','<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">月亮悄悄蒙上一层纱</span><br style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;" />
<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">夜云悄悄隆起崖</span><br style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;" />
<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">曾经年少的我啊</span><br style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;" />
<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">曾经痴心这么想<br />
</span><br style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;" />
<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">如果有一天</span><br style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;" />
<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">如果有一个人</span><br style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;" />
<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">陪我一起看花开</span><br style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;" />
<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">陪我一起看流霞<br />
<br />
<br type="_moz" />
</span>','爱你直到永远','2015-03-25','2011','12','1'),
('18','哈哈哥','王勇智','司云轩','<span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\'; font-size: 14px; line-height: 25.2000007629395px;">人生不止，寂寞不已。<br />
寂寞人生爱无休，寂寞是爱永远的主题。<br />
我和我的影子独处。<br />
它说它有悄悄话想跟我说。<br />
它说它很想念你，<br />
原来，<br />
我和我的影子都在想你。<br />
<br type="_moz" />
</span>','','2015-03-26','2013','12','1'),
('19','王勇智','王勇智','You','<pre id="best-content-245542773" accuse="aContent" class="best-text mb-10" style="margin-top: 0px; margin-bottom: 10px; padding: 0px; font-family: arial, \'courier new\', courier, 宋体, monospace; white-space: pre-wrap; word-wrap: break-word; color: rgb(51, 51, 51); font-size: 14px; line-height: 24px; background-color: rgb(241, 254, 221);">
我以为要是唱的用心良苦,<br />你总会对我多点在乎.<br />我以为虽然爱情已成往事,<br />千言万语说出来可以互相安抚.<br />期待你感动,<br />真实的我们难相处.<br />写词的让我,<br />唱出你要的幸福.<br />谁曾经感动,<br />分手的关头才懂得.<br />离开排行榜更铭心刻骨.<br />我已经相信有些人我永远不必等,<br />所以我明白在灯火阑珊处为什么会哭.<br />你不会相信,<br />嫁给我明天有多幸福.<br />只想你明白,<br />我心甘情愿爱爱爱爱到要吐.<br />那是醉生梦死才能熬成的苦,<br />爱如潮水,<br />我忘了我是谁,<br />至少还有你哭.<br /><br />我想唱一首歌给我们祝福,<br />唱完了我会一个人祝<br />我愿意试着了解从此以后.<br />拥挤的房间一个人的心有多孤独.<br />让我断了气铁了心爱的过火,<br />一回头就找到出路.<br />让我成为了无情的k歌之王.<br />麦克风都让我征服,<br />想不到你若无其事的说:<br />&quot;这样滥情,何苦?&quot;<br />我想来一个吻别作为结束,<br />想不到你只说我不许哭,<br />不该我领悟!
<br type="_moz" /></pre>','谢谢你让我有所成长','2015-03-28','2014','2','24'),
('20','王勇智','王勇智','兮兮','<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;">看着飞舞的尘埃 掉下来</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;">没人发现它存在 多自由自在</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;" />
<br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;">可世界都爱热热闹闹 容不下 我百无聊赖</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;">不应该 一个人 发呆</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;" />
<br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;">只有我 守着安静的沙漠 等待着花开</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;">只有我 看着别人的快乐 竟然会感慨</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;">就让我 听着天大的道理 不愿意明白</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;" />
<br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;">有什么 是应该 不应该</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;" />
<br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;">我的心里住着一个 苍老的小孩</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;">如果世界听不明白 对影子表白</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;">是不是只有我 还在问 为什么 明天更精彩</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;">烟火里 找不到 童真的残骸</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;" />
<br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;">只有我 守着安静的沙漠 等待着花开</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;">只有我 看着别人的快乐 竟然会感慨</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;">就让我 听着天大的道理 不愿意明白</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center; widows: auto;" />','Love you forever','2015-04-07','2013','12','12'),
('21','司云轩','司云轩','兔兔','<ul style="margin: 0px; padding: 0px; list-style: none; color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; widows: auto; zoom: 1;">
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">我在黑暗中</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">化作一个火种</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">想为你</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">点亮整片的星光</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">追随着微风</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">住进了美梦</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">你笑着</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">躲在我心中</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">不要烟火不要星光</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">只要问问内心的想法</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">在我的世界</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">可有个角落</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">是你不曾懂的远方</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">也许我是一道微光</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">却想要给你灿烂的光芒</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">宁愿让我受伤</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">在黑暗的夜晚</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">静静地为你</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">去孤独的照亮</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">就让我是一道微光</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">能让你拥有灿烂的锋芒</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">在寂寞的时分</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">无论飞向何方</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">我也会绽放</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">给你无限微光</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">&nbsp;</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">&nbsp;</li>
</ul>','爱你的心永远不会改变','2015-04-08','','',''),
('22','王勇智','王勇智','兮兮','<ul style="widows: auto; margin: 0px; padding: 0px; list-style: none; color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; zoom: 1;">
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">不要烟火不要星光</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">只要问问内心的想法</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">在我的世界</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">可有个角落</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">是你不曾懂的远方</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">也许我是一道微光</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">却想要给你灿烂的光芒</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">宁愿让我受伤</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">在黑暗的夜晚</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">静静地为你</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">去孤独的照亮</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">就让我是一道微光</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">能让你拥有灿烂的锋芒</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">在寂寞的时分</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">无论飞向何方</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">我也会绽放</li>
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;">给你无限微光</li>
</ul>','莫失莫忘','2015-04-09','2014','2','2'),
('23','司云轩','司云轩','兔兔','<ul style="widows: auto; margin: 0px; padding: 0px; list-style: none; color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; zoom: 1;">
    <li class="ui-lrc-sentence" style="margin: 0px; padding: 0px; list-style: none;"><span style="text-align: center; widows: auto;">趁你还不需要翻来覆去考虑又考虑</span><br style="text-align: center; widows: auto;" />
    <span style="text-align: center; widows: auto;">趁你还不知道 为什么叹气</span><br style="text-align: center; widows: auto;" />
    <span style="text-align: center; widows: auto;">趁你还没学会装模作样证明你自己</span><br style="text-align: center; widows: auto;" />
    <span style="text-align: center; widows: auto;">你想什么什么就是你</span><br style="text-align: center; widows: auto;" />
    <br style="text-align: center; widows: auto;" />
    <span style="text-align: center; widows: auto;">也许你不相信 你也许你没留意</span><br style="text-align: center; widows: auto;" />
    <span style="text-align: center; widows: auto;">有多少人羡慕你 羡慕你年轻</span><br style="text-align: center; widows: auto;" />
    <span style="text-align: center; widows: auto;">这世界属于你 只因为你年轻</span><br style="text-align: center; widows: auto;" />
    <span style="text-align: center; widows: auto;">你可得要抓得紧 回头不容易</span><br style="text-align: center; widows: auto;" />
    <br style="text-align: center; widows: auto;" />
    <span style="text-align: center; widows: auto;">你可知道什么原因 有人羡慕你</span><br style="text-align: center; widows: auto;" />
    <span style="text-align: center; widows: auto;">只因为他们曾经也 年轻</span><br style="text-align: center; widows: auto;" />
    <span style="text-align: center; widows: auto;">你可明白什么道理 有人嫉妒你</span><br style="text-align: center; widows: auto;" />
    <span style="text-align: center; widows: auto;">只因为他们不能 抓得紧</span><br style="text-align: center; widows: auto;" />
    <br style="text-align: center; widows: auto;" />
    <span style="text-align: center; widows: auto;">趁你还不需要翻来覆去考虑又考虑</span><br style="text-align: center; widows: auto;" />
    <span style="text-align: center; widows: auto;">趁你还不知道 为什么叹气</span><br style="text-align: center; widows: auto;" />
    <span style="text-align: center; widows: auto;">趁你还没学会装模作样证明你自己</span><br style="text-align: center; widows: auto;" />
    <span style="text-align: center; widows: auto;">你想什么什么就是你</span></li>
</ul>','爱你直到永远','2015-04-10','2012','2','2'),
('25','司云轩','司云轩','兔兔','在你以后的日子里，<br />
我希望能够有我的陪伴，<br />
和你一起散步，<br />
黄昏漫步在操场上，<br />
我们手牵手就这么一直走下去。<br />
我能想到最浪漫的事，<br />
就是和你一起慢慢变老。<br />
希望你能接受我的表白。<br />
<br />
----Love you MrSi','爱你的心永远不变','2015-04-16','2013','4','5'),
('26','王勇智','王勇智','兮兮','<span style="font-size: 16px;">我想和你背靠着背坐在地毯上，<br />
一起听听音乐聊聊愿望，<br />
我想和你手牵着手走在小路上，<br />
一起闻着花香聆听鸟声，<br />
我能想到的最浪漫的事，<br />
就是和你一起慢慢变老，<br />
希望你能够接受我的表白。</span><br />
<br />
&nbsp; &nbsp;---Love you forever MrWang','爱你直到永远','2015-04-17','2013','2','14'),
('27','司云轩','司云轩','兔纸','<span style="color: rgb(0, 71, 121); font-family: 宋体;">在你以后的日子里，</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">我希望能够有我的陪伴，</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">和你一起散步，</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">黄昏漫步在操场上，</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">我们手牵手就这么一直走下去。</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">我能想到最浪漫的事，</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">就是和你一起慢慢变老。</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">希望你能接受我的表白。<br />
<br />
--Mr SI</span>','爱你直到永远','2015-04-21','','',''),
('28','王勇智','王勇智','兮兮','<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">我坐在床前望着窗外回忆满天</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">生命是华丽错觉 时间是贼偷走一切</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">七岁的那一年抓住那只蝉以为能抓住夏天</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">十七岁的那年吻过她的脸就以为和她能永远</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">有没有那么一种永远 永远不改变</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">拥抱过的美丽都再也不破碎</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">让险峻岁月不能在脸上撒野</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">让生离和死别都遥远有谁能听见</span>','爱你直到永远','2015-05-03','2012','12','12'),
('29','王勇智','王勇智','兮兮','<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">我坐在床前转过头看谁在沉睡</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">那一张苍老的脸 好像是我紧闭双眼</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">曾经是爱我的和我深爱的 都围绕在我身边</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">带不走的那些遗憾和眷恋 就化成最后一滴眼泪</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">有没有那么一滴眼泪能洗掉后悔</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">化成大雨降落在回不去的街</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">再给我一次机会将故事改写</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">还欠了他一生的一句抱歉.</span>','Love you forever','2015-05-04','2012','12','12'),
('30','司云轩','司云轩','兔纸','<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">有没有那么一个世界永远不天黑</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">星星太阳万物都听我的指挥</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">月亮不忙着圆缺 春天不走远</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">树梢紧紧拥抱着树叶有谁能听见</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">耳际眼前此生重演 <br />
是我来自漆黑而又回归漆黑</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">人间瞬间天地之间 <br />
下次我又是谁</span>','爱你的心永远不会改变','2015-05-05','','',''),
('31','王勇智','王勇智','兮兮','<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">有没有那么一朵玫瑰永远不凋谢</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">永远骄傲和完美永远不妥协</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">为何人生最后会像一张纸屑</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">还不如一片花瓣曾经鲜艳</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">有没有那么一张书签停止那一天</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">最单纯的笑脸和最美那一年</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">书包里面装满了蛋糕和汽水</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">双眼只有无猜和无邪让我们无法无天</span>','爱你的心永远不会改变','2015-05-06','2012','12','12'),
('32','司云轩','司云轩','兔纸','<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">有没有那么一首诗篇找不到句点</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">青春永远定居在我们的岁月</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">男孩和女孩都有吉他和舞鞋</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">笑忘人间的苦痛只有甜美</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">有没有那么一个明天重头过一遍</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">让我再次感受曾挥霍的昨天</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">无论生存或生活我都不浪费</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">不让故事这么的后悔</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">有谁能听见 我不要告别</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">坐在床前看着指尖已经如烟</span>','Love you forever','2015-05-07','','',''),
('33','王勇智','王勇智','兮兮','<span style="font-size: 16px;"><span style="font-family: 宋体;"><span style="color: rgb(0, 71, 121); text-align: justify;">你要相信这个世界上一定有一个人，<br />
ta会穿越茫茫的人流、<br />
怀着沉甸甸的爱和满腔的热情走进你、<br />
抓紧你，<br />
只是你要等。<br />
而在等待的过程中我们要让自已变得更好。<br />
因为你喜欢的那个人<br />
一定会在你变得更好的路上<br />
和你<br />
相遇!</span></span></span>','Love you forever!','2015-05-09','2012','12','12'),
('34','司云轩','司云轩','兔兔','<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">多想要找到一丝挣扎在你脸上，</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">可是你美得冷得淡得像月亮，</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">等着你的那辆车 灯闪一下，</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">像催你草草断了我们的过往。<br />
...................<br />
</span><span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">约好要每年回到初拥吻的地方，</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">划一个记号写下相恋的感想，</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">等明年我剩一个人 坐在堤防，</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">改唱首什么歌来纪念爱的傻。</span>','爱你的心永不变','2015-05-11','','',''),
('35','王勇智','王勇智','兮兮','<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">你要相信这个世界上一定有一个人，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">ta会穿越茫茫的人流、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">怀着沉甸甸的爱和满腔的热情走进你、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">抓紧你，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">只是你要等。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">而在等待的过程中我们要让自已变得更好。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">因为你喜欢的那个人</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">一定会在你变得更好的路上</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">和你</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">相遇!</span>','爱你直到永远','2015-05-13','2012','12','12'),
('36','王勇智','王勇智','兮兮','<span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;">曾经以为，我会是你今生最美的遇见，</span><br style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;">会是你此生最美的霓裳，最后的风景。</span><br style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;">走过花开花落，灿烂却没有结果。</span><br style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;">曾经的伴君天涯终不悔，如今的浓浓相思曲空赋;曾 经的平生至爱我一人，</span><br style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;">如今的天涯从此各西东;曾经的此生但为君前醉，</span><br style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;">如今的望断天涯何处寻？</span><br style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;">原来再见初见时的惊艳时光，</span><br style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;">只不过是你一场有口无心的承诺。</span>','Love you forever!','2015-05-15','2012','12','12'),
('37','司云轩','司云轩','兔兔','<span style="color: rgb(0, 71, 121); font-family: 宋体;">在你以后的日子里，</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">我希望能够有我的陪伴，</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">和你一起散步，</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">黄昏漫步在操场上，</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">我们手牵手就这么一直走下去。</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">我能想到最浪漫的事，</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">就是和你一起慢慢变老。</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">希望你能接受我的表白。<br />
<br />
--Mr SI</span><span style="color: rgb(0, 71, 121); font-family: 宋体;">&nbsp;</span>','爱你的心永不变','2015-05-17','','',''),
('38','王勇智','王勇智','兮兮','<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">我想和你背靠着背坐在地毯上，<br />
一起听听音乐聊聊愿望，<br />
我想和你手牵着手走在小路上，<br />
一起闻着花香聆听鸟声，<br />
我能想到的最浪漫的事，<br />
就是和你一起慢慢变老，<br />
希望你能够接受我的表白。</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">&nbsp; &nbsp;---Love you forever MrWang</span>','Love you forever!','2015-05-19','2012','12','12'),
('39','王勇智','王勇智','兮兮','<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">我想和你背靠着背坐在地毯上，<br />
一起听听音乐聊聊愿望，<br />
我想和你手牵着手走在小路上，<br />
一起闻着花香聆听鸟声，<br />
我能想到的最浪漫的事，<br />
就是和你一起慢慢变老，<br />
希望你能够接受我的表白。</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">&nbsp; &nbsp;---Love you forever MrWang</span>','Love you forever!','2015-05-18','2012','12','12'),
('40','王勇智','王勇智','兮兮','<span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;">曾经以为，我会是你今生最美的遇见，</span><br style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;">会是你此生最美的霓裳，最后的风景。</span><br style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;">走过花开花落，灿烂却没有结果。</span><br style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;">曾经的伴君天涯终不悔，如今的浓浓相思曲空赋;曾 经的平生至爱我一人，</span><br style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;">如今的天涯从此各西东;曾经的此生但为君前醉，</span><br style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;">如今的望断天涯何处寻？</span><br style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;">原来再见初见时的惊艳时光，</span><br style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;" />
<span style="color: rgb(51, 51, 51); font-family: \'Microsoft Yahei\', 微软雅黑, arial, 宋体, sans-serif; font-size: 16px; line-height: 28px; text-align: justify;">只不过是你一场有口无心的承诺。</span>&nbsp;','爱你直到永远','2015-05-21','2012','12','12'),
('41','司云轩','司云轩','兔纸','<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">我想和你背靠着背坐在地毯上，<br />
一起听听音乐聊聊愿望，<br />
我想和你手牵着手走在小路上，<br />
一起闻着花香聆听鸟声，<br />
我能想到的最浪漫的事，<br />
就是和你一起慢慢变老，<br />
希望你能够接受我的表白。</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">&nbsp; &nbsp;---Love you forever MrWang</span>&nbsp;','爱你直到永远','2015-05-22','','',''),
('42','王勇智','王勇智','兮兮','<span style="font-size: 16px;"><span style="color: rgb(0, 71, 121); font-family: 宋体;">在你以后的日子里，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 12px;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">我希望能够有我的陪伴，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 12px;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">和你一起散步，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 12px;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">黄昏漫步在操场上，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 12px;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">我们手牵手就这么一直走下去。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 12px;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">我能想到最浪漫的事，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 12px;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">就是和你一起慢慢变老。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 12px;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体;">希望你能接受我的表白。<br />
<br />
--Mr Wang</span></span>','Love you forever','2015-05-23','2012','12','12'),
('43','王勇智','王勇智','兮兮','<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">你要相信这个世界上一定有一个人，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">ta会穿越茫茫的人流、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">怀着沉甸甸的爱和满腔的热情走进你、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">抓紧你，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">只是你要等。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">而在等待的过程中我们要让自已变得更好。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">因为你喜欢的那个人</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">一定会在你变得更好的路上</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">和你</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">相遇!<br />
</span>--------Mr Wang&nbsp;','爱你的心永远不变','2015-05-24','2012','12','12'),
('44','司云轩','司云轩','兔兔','<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">有没有那么一首诗篇找不到句点</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">青春永远定居在我们的岁月</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">男孩和女孩都有吉他和舞鞋</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">笑忘人间的苦痛只有甜美</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">有没有那么一个明天重头过一遍</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">让我再次感受曾挥霍的昨天</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">无论生存或生活我都不浪费</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">不让故事这么的后悔</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">有谁能听见 我不要告别</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">坐在床前看着指尖已经如烟</span>','Love you forever','2015-05-25','','',''),
('45','王勇智','王勇智','兮兮','<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">我坐在床前望着窗外回忆满天</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">生命是华丽错觉 时间是贼偷走一切</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">七岁的那一年抓住那只蝉以为能抓住夏天</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">十七岁的那年吻过她的脸就以为和她能永远</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">有没有那么一种永远 永远不改变</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">拥抱过的美丽都再也不破碎</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">让险峻岁月不能在脸上撒野</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">让生离和死别都遥远有谁能听见</span>&nbsp;','爱你直到永远','2015-05-26','2012','12','12'),
('46','王勇智','王勇智','兮兮','&nbsp;<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">我坐在床前望着窗外回忆满天</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">生命是华丽错觉 时间是贼偷走一切</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">七岁的那一年抓住那只蝉以为能抓住夏天</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">十七岁的那年吻过她的脸就以为和她能永远</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">有没有那么一种永远 永远不改变</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">拥抱过的美丽都再也不破碎</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">让险峻岁月不能在脸上撒野</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">让生离和死别都遥远有谁能听见</span>','爱你直到永远','2015-06-01','2012','12','12'),
('47','王勇智','王勇智','兮兮','&nbsp;<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">你要相信这个世界上一定有一个人，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">ta会穿越茫茫的人流、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">怀着沉甸甸的爱和满腔的热情走进你、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">抓紧你，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">只是你要等。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">而在等待的过程中我们要让自已变得更好。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">因为你喜欢的那个人</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">一定会在你变得更好的路上</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">和你</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">相遇!<br />
</span><span style="color: rgb(0, 71, 121); font-family: 宋体;">--------Mr Wang &nbsp;</span>','Love you forever','2015-06-03','2012','12','12'),
('48','王勇智','王勇智','兮兮','&nbsp;<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">你要相信这个世界上一定有一个人，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">ta会穿越茫茫的人流、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">怀着沉甸甸的爱和满腔的热情走进你、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">抓紧你，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">只是你要等。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">而在等待的过程中我们要让自已变得更好。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">因为你喜欢的那个人</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">一定会在你变得更好的路上</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">和你</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">相遇!<br />
</span><span style="color: rgb(0, 71, 121); font-family: 宋体;">--------Mr Wang &nbsp;</span>','Love you forever','2015-06-05','2012','12','12'),
('49','MrWang','王勇智','兮兮','&nbsp;<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">你要相信这个世界上一定有一个人，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">ta会穿越茫茫的人流、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">怀着沉甸甸的爱和满腔的热情走进你、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">抓紧你，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">只是你要等。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">而在等待的过程中我们要让自已变得更好。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">因为你喜欢的那个人</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">一定会在你变得更好的路上</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">和你</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">相遇!<br />
</span><span style="color: rgb(0, 71, 121); font-family: 宋体;">--------Mr Wang &nbsp;</span>','Love you forever','2015-06-07','2012','',''),
('50','王勇智','MrWang','兮兮','<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">你要相信这个世界上一定有一个人，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">ta会穿越茫茫的人流、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">怀着沉甸甸的爱和满腔的热情走进你、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">抓紧你，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">只是你要等。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">而在等待的过程中我们要让自已变得更好。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">因为你喜欢的那个人</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">一定会在你变得更好的路上</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">和你</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">相遇!<br />
</span><span style="color: rgb(0, 71, 121); font-family: 宋体;">--------Mr Wang &nbsp;</span>','爱你直到永远','2015-06-09','2012','12','12'),
('51','王勇智','王勇智','兮兮','<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">你要相信这个世界上一定有一个人，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">ta会穿越茫茫的人流、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">怀着沉甸甸的爱和满腔的热情走进你、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">抓紧你，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">只是你要等。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">而在等待的过程中我们要让自已变得更好。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">因为你喜欢的那个人</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">一定会在你变得更好的路上</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">和你</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">相遇!<br />
</span><span style="color: rgb(0, 71, 121); font-family: 宋体;">--------Mr Wang &nbsp;</span>','Love you forever','2015-06-11','2012','12','12'),
('52','司云轩','司云轩','兔兔','<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">你要相信这个世界上一定有一个人，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">ta会穿越茫茫的人流、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">怀着沉甸甸的爱和满腔的热情走进你、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">抓紧你，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">只是你要等。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">而在等待的过程中我们要让自已变得更好。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">因为你喜欢的那个人</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">一定会在你变得更好的路上</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">和你</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">相遇!<br />
</span><span style="color: rgb(0, 71, 121); font-family: 宋体;">--------Mr Wang &nbsp;</span>','爱你直到永远','2015-06-13','','',''),
('53','王勇智','王勇智','兮兮','<div>有一天当你穿上西装成为别人的新郎&nbsp;</div>
<div>我会闭口不提曾经的疯狂,</div>
<div>有一天我穿上婚纱成为别人的新娘&nbsp;</div>
<div>你依旧是我最初的梦想&nbsp;</div>
<div>或许是多年再见各自安静生活数年</div>
<div>在某个人潮拥挤的街头透过公车的玻璃窗突然看见你</div>
<div>想让司机马上停车想用力拍打窗户来引起你的注意</div>
<div>想从车上跳下来想奔跑想大喊大叫把整个阻隔在你我之间的世界撕裂</div>
<div>呼吸急促面额潮红手指颤抖</div>
<div>在激烈的想象中把自己感动的快哭了</div>
<div>而事实却总是一动不动安静的看着你远去&nbsp;</div>
<div>我知道我只能陪你走这一段路</div>
<div>&nbsp;</div>','Love you forever','2015-06-14','2012','12','12'),
('54','司云轩','MrSi','兔纸','<div>有一天当你穿上西装成为别人的新郎&nbsp;</div>
<div>我会闭口不提曾经的疯狂,</div>
<div>有一天我穿上婚纱成为别人的新娘&nbsp;</div>
<div>你依旧是我最初的梦想&nbsp;</div>
<div>或许是多年再见各自安静生活数年</div>
<div>在某个人潮拥挤的街头透过公车的玻璃窗突然看见你</div>
<div>想让司机马上停车想用力拍打窗户来引起你的注意</div>
<div>想从车上跳下来想奔跑想大喊大叫把整个阻隔在你我之间的世界撕裂</div>
<div>呼吸急促面额潮红手指颤抖</div>
<div>在激烈的想象中把自己感动的快哭了</div>
<div>而事实却总是一动不动安静的看着你远去&nbsp;</div>
<div>我知道我只能陪你走这一段路</div>
<div>&nbsp;</div>','爱你直到永远','2015-06-15','2013','11','11'),
('55','王勇智','MrWang','兮兮','<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">你要相信这个世界上一定有一个人，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">ta会穿越茫茫的人流、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">怀着沉甸甸的爱和满腔的热情走进你、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">抓紧你，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">只是你要等。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">而在等待的过程中我们要让自已变得更好。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">因为你喜欢的那个人</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">一定会在你变得更好的路上</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">和你</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">相遇!<br />
</span><span style="color: rgb(0, 71, 121); font-family: 宋体;">--------Mr Wang &nbsp;</span><span style="color: rgb(0, 71, 121); font-family: 宋体;">&nbsp;</span>','Love you forever','2015-06-16','2012','12','12'),
('56','小思','小思','兔纸','<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">在你以后的日子里，<br style="font-size: 12px;" />
我希望能够有我的陪伴，<br style="font-size: 12px;" />
和你一起散步，<br style="font-size: 12px;" />
黄昏漫步在操场上，<br style="font-size: 12px;" />
我们手牵手就这么一直走下去。<br style="font-size: 12px;" />
我能想到最浪漫的事，<br style="font-size: 12px;" />
就是和你一起慢慢变老。<br style="font-size: 12px;" />
希望你能接受我的表白。<br />
<br />
--MrSi</span>','爱你直到永远','2015-06-17','','',''),
('57','王勇智','王勇智','兮兮','<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">你要相信这个世界上一定有一个人，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">ta会穿越茫茫的人流、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">怀着沉甸甸的爱和满腔的热情走进你、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">抓紧你，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">只是你要等。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">而在等待的过程中我们要让自已变得更好。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">因为你喜欢的那个人</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">一定会在你变得更好的路上</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">和你</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">相遇!<br />
</span><span style="color: rgb(0, 71, 121); font-family: 宋体;">--------Mr Wang &nbsp;</span><span style="color: rgb(0, 71, 121); font-family: 宋体;">&nbsp;</span>','Love you forever','2015-06-19','2012','12','12'),
('58','司云轩','司云轩','兔纸','<div style="color: rgb(0, 71, 121); font-family: 宋体;"><span style="font-size: 16px;">在你以后的日子里，<br style="font-size: 12px;" />
我希望能够有我的陪伴，<br style="font-size: 12px;" />
和你一起散步，<br style="font-size: 12px;" />
黄昏漫步在操场上，<br style="font-size: 12px;" />
我们手牵手就这么一直走下去。<br style="font-size: 12px;" />
我能想到最浪漫的事，<br style="font-size: 12px;" />
就是和你一起慢慢变老。<br style="font-size: 12px;" />
希望你能接受我的表白。<br />
<br />
--MrSi</span></div>','爱你直到永远','2015-06-21','','',''),
('59','王勇智','王勇智','兮兮','<div style="color: rgb(0, 71, 121); font-family: 宋体;">有一天当你穿上西装成为别人的新郎&nbsp;</div>
<div style="color: rgb(0, 71, 121); font-family: 宋体;">我会闭口不提曾经的疯狂,</div>
<div style="color: rgb(0, 71, 121); font-family: 宋体;">有一天我穿上婚纱成为别人的新娘&nbsp;</div>
<div style="color: rgb(0, 71, 121); font-family: 宋体;">你依旧是我最初的梦想&nbsp;</div>
<div style="color: rgb(0, 71, 121); font-family: 宋体;">或许是多年再见各自安静生活数年</div>
<div style="color: rgb(0, 71, 121); font-family: 宋体;">在某个人潮拥挤的街头透过公车的玻璃窗突然看见你</div>
<div style="color: rgb(0, 71, 121); font-family: 宋体;">想让司机马上停车想用力拍打窗户来引起你的注意</div>
<div style="color: rgb(0, 71, 121); font-family: 宋体;">想从车上跳下来想奔跑想大喊大叫把整个阻隔在你我之间的世界撕裂</div>
<div style="color: rgb(0, 71, 121); font-family: 宋体;">呼吸急促面额潮红手指颤抖</div>
<div style="color: rgb(0, 71, 121); font-family: 宋体;">在激烈的想象中把自己感动的快哭了</div>
<div style="color: rgb(0, 71, 121); font-family: 宋体;">而事实却总是一动不动安静的看着你远去&nbsp;</div>
<div style="color: rgb(0, 71, 121); font-family: 宋体;">我知道我只能陪你走这一段路</div>','Love you forever','2015-06-23','2012','12','12'),
('60','司云轩','司云轩','兔兔','<span class="space" style="box-sizing: border-box; margin: 0px 0px 0px 7px; padding: 0px; list-style-type: none; color: rgb(51, 51, 51); font-family: Consolas, Monaco, \'Bitstream Vera Sans Mono\', \'Courier New\', sans-serif; line-height: 17.142858505249023px; background-color: rgb(255, 255, 238);"><span class="space" style="box-sizing: border-box; margin: 0px 0px 0px 7px; padding: 0px; list-style-type: none;"><span style="box-sizing: border-box; margin: 0px; padding: 0px; list-style-type: none; color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">你要相信这个世界上一定有一个人，</span><br style="box-sizing: border-box; margin: 0px; padding: 0px; list-style-type: none; color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="box-sizing: border-box; margin: 0px; padding: 0px; list-style-type: none; color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">ta会穿越茫茫的人流、</span><br style="box-sizing: border-box; margin: 0px; padding: 0px; list-style-type: none; color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="box-sizing: border-box; margin: 0px; padding: 0px; list-style-type: none; color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">怀着沉甸甸的爱和满腔的热情走进你、</span><br style="box-sizing: border-box; margin: 0px; padding: 0px; list-style-type: none; color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="box-sizing: border-box; margin: 0px; padding: 0px; list-style-type: none; color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">抓紧你，</span><br style="box-sizing: border-box; margin: 0px; padding: 0px; list-style-type: none; color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="box-sizing: border-box; margin: 0px; padding: 0px; list-style-type: none; color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">只是你要等。</span><br style="box-sizing: border-box; margin: 0px; padding: 0px; list-style-type: none; color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="box-sizing: border-box; margin: 0px; padding: 0px; list-style-type: none; color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">而在等待的过程中我们要让自已变得更好。</span><br style="box-sizing: border-box; margin: 0px; padding: 0px; list-style-type: none; color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="box-sizing: border-box; margin: 0px; padding: 0px; list-style-type: none; color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">因为你喜欢的那个人</span><br style="box-sizing: border-box; margin: 0px; padding: 0px; list-style-type: none; color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="box-sizing: border-box; margin: 0px; padding: 0px; list-style-type: none; color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">一定会在你变得更好的路上</span><br style="box-sizing: border-box; margin: 0px; padding: 0px; list-style-type: none; color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="box-sizing: border-box; margin: 0px; padding: 0px; list-style-type: none; color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">和你</span><br style="box-sizing: border-box; margin: 0px; padding: 0px; list-style-type: none; color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="box-sizing: border-box; margin: 0px; padding: 0px; list-style-type: none; color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">相遇!<br style="box-sizing: border-box; margin: 0px; padding: 0px; list-style-type: none;" />
</span><span style="box-sizing: border-box; margin: 0px; padding: 0px; list-style-type: none; color: rgb(0, 71, 121); font-family: 宋体;">--------Mr Si</span></span></span>','爱你直到永远','2015-06-25','','',''),
('61','司云轩','司云轩','兔兔','<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">在你以后的日子里，</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">我希望能够有我的陪伴，</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">和你一起散步，</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">黄昏漫步在操场上，</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">我们手牵手就这么一直走下去。</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">我能想到最浪漫的事，</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">就是和你一起慢慢变老。</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">希望你能接受我的表白。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;" />
<br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">--MrSi</span>','Love You Forever','2015-06-27','2013','10','11'),
('62','王勇智','王勇智','兮兮','<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">你要相信这个世界上一定有一个人，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">ta会穿越茫茫的人流、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">怀着沉甸甸的爱和满腔的热情走进你、</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">抓紧你，</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">只是你要等。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">而在等待的过程中我们要让自已变得更好。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">因为你喜欢的那个人</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">一定会在你变得更好的路上</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">和你</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px; text-align: justify;">相遇!<br />
</span><span style="color: rgb(0, 71, 121); font-family: 宋体;">--------Mr Wang&nbsp;</span>&nbsp;','爱你直到永远','2015-06-29','2012','12','12'),
('63','王勇智','王勇智','兮兮','<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">背靠着背 坐在地毯上</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">听听音乐 聊聊愿望</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">你希望我越来越温柔</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">我希望你放我在心上</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">你说想送我个浪漫的梦想</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">谢谢我带你找到天堂</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">哪怕用一辈子才能完成</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">只要我讲你就记住不忘</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">我能想到最浪漫的事</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">就是和你一起慢慢变老</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">一路上收藏点点滴滴的欢笑</span><br style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;" />
<span style="color: rgb(51, 51, 51); font-family: arial; font-size: 13px; line-height: 20.0200004577637px; text-align: center;">留到以后 坐着摇椅 慢慢聊</span>','Love you forever','2015-07-01','2012','12','12'),
('64','王勇智','MrWang','兮兮','<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">月亮悄悄蒙上一层纱</span><br style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;" />
<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">夜云悄悄隆起崖</span><br style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;" />
<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">曾经年少的我啊</span><br style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;" />
<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">曾经痴心这么想<br />
</span><br style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;" />
<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">如果有一天</span><br style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;" />
<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">如果有一个人</span><br style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;" />
<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">陪我一起看花开</span><br style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;" />
<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">陪我一起看流霞<br />
<br />
</span>-----MrWang&nbsp;','爱你直到永远','2015-07-03','','',''),
('65','司云轩','司云轩','兔兔','<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">在你以后的日子里，</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">我希望能够有我的陪伴，</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">和你一起散步，</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">黄昏漫步在操场上，</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">我们手牵手就这么一直走下去。</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">我能想到最浪漫的事，</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">就是和你一起慢慢变老。</span><br style="color: rgb(0, 71, 121); font-family: 宋体;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">希望你能接受我的表白。</span><br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;" />
<br style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;" />
<span style="color: rgb(0, 71, 121); font-family: 宋体; font-size: 16px;">--MrSi</span>&nbsp;','爱你直到永远','2015-07-05','2012','10','11'),
('66','王勇智','王勇智','兮兮','<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">月亮悄悄蒙上一层纱</span><br style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;" />
<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">夜云悄悄隆起崖</span><br style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;" />
<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">曾经年少的我啊</span><br style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;" />
<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">曾经痴心这么想<br />
</span><br style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;" />
<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">如果有一天</span><br style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;" />
<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">如果有一个人</span><br style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;" />
<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">陪我一起看花开</span><br style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;" />
<span style="color: rgb(102, 102, 102); font-family: Arial, sans-serif; line-height: 19.2000007629395px;">陪我一起看流霞<br />
<br />
</span><span style="color: rgb(0, 71, 121); font-family: 宋体;">-----MrWang</span>','爱你直到永永远远','2015-07-07','2012','12','12');
DROP TABLE IF EXISTS  `t_forbidusername`;
CREATE TABLE `t_forbidusername` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `ForbidUserName` varchar(20) DEFAULT NULL COMMENT '禁用的用户名',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

insert into `t_forbidusername`(`Id`,`ForbidUserName`) values
('1','王勇智'),
('2','习近平'),
('3','胡锦涛'),
('4','毛泽东'),
('5','邓小平'),
('6','管理员'),
('7','VIP'),
('8','vip'),
('9','Vip'),
('10','超级管理员'),
('11','你大爷');
DROP TABLE IF EXISTS  `t_logininfo`;
CREATE TABLE `t_logininfo` (
  `Id` bigint(20) NOT NULL COMMENT '编号',
  `UserId` bigint(20) NOT NULL COMMENT '外键——用户编号',
  `LoginPlace` varchar(50) DEFAULT NULL COMMENT '登录地点',
  `IpAddress` varchar(20) DEFAULT NULL COMMENT '登录ip地址',
  `LoginTime` datetime DEFAULT NULL COMMENT '登录时间',
  PRIMARY KEY (`Id`),
  KEY `ForeignKey_LoginInfo` (`UserId`),
  CONSTRAINT `ForeignKey_LoginInfo` FOREIGN KEY (`UserId`) REFERENCES `t_user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `t_message`;
CREATE TABLE `t_message` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `ReceiveRealName` varchar(20) DEFAULT NULL COMMENT '有人表白并记录真实姓名时会插入',
  `MsgContent` longtext COMMENT '消息内容',
  `MsgType` varchar(50) DEFAULT NULL COMMENT '消息类型',
  `PostTime` datetime DEFAULT NULL COMMENT '发布时间',
  `ReleaseContentId` bigint(20) DEFAULT NULL COMMENT '对应表白内容',
  `ReplayId` bigint(20) DEFAULT NULL COMMENT '回复编号',
  `ReplyToUser` bigint(20) DEFAULT NULL COMMENT '回复消息对应的发表表白的用户',
  PRIMARY KEY (`Id`),
  KEY `releaseContent` (`ReleaseContentId`),
  KEY `replayContent` (`ReplayId`),
  KEY `replayToUser` (`ReplyToUser`),
  CONSTRAINT `replayToUser` FOREIGN KEY (`ReplyToUser`) REFERENCES `t_user` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `releaseContent` FOREIGN KEY (`ReleaseContentId`) REFERENCES `t_releasecontent` (`Id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `replayContent` FOREIGN KEY (`ReplayId`) REFERENCES `t_replay` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;

insert into `t_message`(`Id`,`ReceiveRealName`,`MsgContent`,`MsgType`,`PostTime`,`ReleaseContentId`,`ReplayId`,`ReplyToUser`) values
('4','王勇智','有一条关于您的表白消息，点击查看','表白消息','2015-03-04 10:18:38','1',null,null),
('5',null,'感谢您的注册，快来体验吧!','系统消息','2015-03-10 10:16:21',null,null,null),
('6','王勇智','有一条关于您的表白消息，点击查看','表白消息','2015-02-19 15:50:21','11',null,null),
('7','王勇智','有一条关于您的表白消息，点击查看','表白消息','2015-02-19 15:50:36','12',null,null),
('8','王勇智','有一条关于您的表白消息，对方是女生，点击查看','表白消息','2015-02-26 12:36:06','124',null,null),
('9','二蛋','有一条可能关于您的表白消息，对方是男生，点击查看','表白消息','2015-03-14 21:01:23','139',null,null),
('10','小钊','有一条可能关于您的表白消息，对方是男生，点击查看','表白消息','2015-03-16 19:42:03','140',null,null),
('11','云轩','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-03-16 19:47:11','141',null,null),
('12','李修寒','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-03-16 22:16:17','142',null,null),
('13','王勇智','有一条可能关于您的表白消息，对方是男生，点击查看','表白消息','2015-03-16 22:40:19','143',null,null),
('14','云轩','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-03-18 22:48:11','144',null,null),
('16','小兔','有一条可能关于您的表白消息，对方是男生，点击查看','表白消息','2015-03-22 23:16:26','146',null,null),
('17','司云轩','有一条可能关于您的表白消息，对方是男生，点击查看','表白消息','2015-03-22 23:30:24','147',null,null),
('18','司云轩','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-03-23 23:15:29','148',null,null),
('19','司云轩','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-04-07 12:09:48','149',null,null),
('20','200','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-04-10 19:14:59','150',null,null),
('21','王勇智','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-04-13 23:06:45','152',null,null),
('22','王勇智','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-04-15 23:30:18','153',null,null),
('24','王勇智','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-04-18 18:42:44','155',null,null),
('25','她','有一条可能关于您的表白消息，对方是男生，点击查看','表白消息','2015-04-26 10:21:18','156',null,null),
('26','baby’breath','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-05-02 19:02:11','157',null,null),
('27','何宇健','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-05-08 21:34:08','158',null,null),
('28','王勇智','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-05-09 22:48:05','159',null,null),
('29','何大大','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-05-13 20:00:53','160',null,null),
('30','何大大','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-05-14 21:59:36','161',null,null),
('31','王勇智','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-05-23 12:16:08','162',null,null),
('32','何宇健','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-05-27 21:43:48','163',null,null),
('33','李晓琪','有一条可能关于您的表白消息，对方是男生，点击查看','表白消息','2015-06-06 15:32:02','166',null,null),
('34','何宇键','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-06-07 17:47:16','167',null,null),
('35','王勇智','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-06-10 23:20:57','168',null,null),
('36','王勇智','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-06-13 08:26:07','169',null,null),
('37','王勇智','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-06-14 12:28:21','170',null,null),
('38','王勇智','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-06-21 08:56:23','171',null,null),
('39','冬冬','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-06-21 22:26:30','172',null,null),
('40','冬冬','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-06-21 22:30:02','173',null,null),
('42',null,'有一条关于您的回复消息，回复者是：[adminTest],点击查看','回复消息','2015-07-03 14:11:03','171','76','1'),
('43',null,'有一条关于您的回复消息，回复者是：[莫失莫忘],点击查看','回复消息','2015-07-03 14:12:51','172','77','53'),
('44',null,'有一条关于您的回复消息，回复者是：[莫失莫忘],点击查看','回复消息','2015-07-03 23:30:06','143','78','27'),
('45',null,'有一条关于您的回复消息，回复者是：[莫失莫忘],点击查看','回复消息','2015-07-03 23:32:11','150','79','14'),
('46',null,'有一条关于您的回复消息，回复者是：[莫失莫忘],点击查看','回复消息','2015-07-05 00:02:01','150','80','14'),
('48','王勇智','有一条可能关于您的表白消息，对方是女生，点击查看','表白消息','2015-07-05 13:48:30','176',null,null),
('49',null,'有一条关于您的回复消息，回复者是：[莫失莫忘],点击查看','回复消息','2015-07-05 14:01:22','157','82','35');
DROP TABLE IF EXISTS  `t_problem`;
CREATE TABLE `t_problem` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `Email` varchar(50) DEFAULT NULL COMMENT '邮箱地址',
  `Description` varchar(200) DEFAULT NULL COMMENT '遇到问题描述',
  `SubTime` datetime DEFAULT NULL COMMENT '提交时间',
  `IsSolve` varchar(20) DEFAULT NULL COMMENT '是否解决',
  `IsUsable` varchar(20) DEFAULT NULL COMMENT '是否有用',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

insert into `t_problem`(`Id`,`Email`,`Description`,`SubTime`,`IsSolve`,`IsUsable`) values
('1','849451478@qq.com','示例--初始化问题','2015-03-07 09:01:22','是','是');
DROP TABLE IF EXISTS  `t_releasecontent`;
CREATE TABLE `t_releasecontent` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `UserId` bigint(20) NOT NULL COMMENT '外键——用户编号',
  `ReleaseContent` text COMMENT '发表内容',
  `RealName` varchar(20) DEFAULT NULL COMMENT '被表白者的真实姓名',
  `Background` varchar(10) DEFAULT NULL COMMENT '背景图片',
  `IsRecommand` int(11) DEFAULT NULL COMMENT '是否推荐',
  `IpAddress` varchar(20) DEFAULT NULL COMMENT '发布者ip地址',
  `ReleaseTime` datetime DEFAULT NULL COMMENT '发表时间',
  `ViewCount` int(11) DEFAULT '0' COMMENT '浏览次数',
  `CommentCount` int(11) DEFAULT '0' COMMENT '评论次数',
  PRIMARY KEY (`Id`),
  KEY `ForeignKey_ReleaseContent` (`UserId`),
  CONSTRAINT `ForeignKey_ReleaseContent` FOREIGN KEY (`UserId`) REFERENCES `t_user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=utf8;

insert into `t_releasecontent`(`Id`,`UserId`,`ReleaseContent`,`RealName`,`Background`,`IsRecommand`,`IpAddress`,`ReleaseTime`,`ViewCount`,`CommentCount`) values
('1','1','青梅老去，竹马枯萎，从此我爱上的人都像你。','小司','0','0',null,'2015-02-06 14:44:59','58','1'),
('2','1','流年里，我的爱在默默地等你，因为有爱的生活是开心的，有爱的生活就有人生的壮美，有爱的生活就有如花的你。在情感的天空里，爱是神圣的，最美的，最使人风华当年，神情激昂。','小司','0','0',null,'2015-02-06 14:46:59','40','0'),
('3','1','给我一百万个恋恋不舍的白天也觉不够，给我一辈子温馨浪漫的夜晚还嫌太少，和你在一起总觉得世界无法看透，永远不会有尽头。',null,'0','0',null,'2015-02-10 21:50:56','43','1'),
('10','6','似曾几千年的相遇，在天与地之间，构成美丽的图画。好美丽的接触，好动人的篇章，你是词我就是阕，圆了你的美梦，这就是超前，爱的飘洒。',null,'0','0',null,'2015-02-10 15:49:58','0','0'),
('11','1','给我一双手，让你依赖，给我一双眼，送你离开，就像蝴蝶飞不过沧海，没有谁忍心责怪，给我一刹那，对你宠爱，给我一辈子，送你离开。','小司','0','0','192.168.1.102','2015-02-19 15:50:21','4','0'),
('12','1','我以为时间是最好的偏方，可治好的全是皮外伤。我的笑容，可以给任何人，但我的心，只能给一个人。','司云轩','0','0','192.168.1.102','2015-02-19 15:50:36','16','0'),
('13','1','以落花为茗，以青灯为伴，捧一册古卷，吟一首唐诗，赋一阕宋词，轻展一方素笺，细研一池墨香，为你书写一纸思念，情寄一泓缠绵','','0','0','192.168.1.102','2015-02-19 15:50:42','3','0'),
('14','1','牵手走过爱情的花园，沉浸在醉人的花香，喁喁而语浅笑嫣然，你的一颦一笑，拨动我的心弦，若能每日面对你的笑颜，却胜似天上人间，纵然是时光荏苒，真爱永不改变。','','0','0','192.168.1.102','2015-02-19 15:50:47','0','0'),
('15','1','如果你是茶叶，我就用开水泡着；如果你是花儿，我就用阳光照着；如果你是白云，我就用清风托着；如果你是风筝，我就用丝线牵着；而你是我倾心的恋人，所以我无时无刻都用心把你装着。','','0','0','192.168.1.102','2015-02-19 15:50:52','0','0'),
('16','1','每一天每一夜我都祈祷，明天的明天的明天，真的很想和你去吹吹风。','','0','0','192.168.1.102','2015-02-19 15:50:57','0','0'),
('17','1','每当看到你的时候，我总会沉默，因为有天使正在路过。','','0','0','192.168.1.102','2015-02-19 15:51:01','0','0'),
('18','1','没有你,我的天空少了一片色彩；没有你，我的世界多了一种思念。','','0','0','192.168.1.102','2015-02-19 15:51:05','1','0'),
('19','1','如果爱情是一朵花，就让它开在我心里，败在我心里，深埋在我心里。','','0','0','192.168.1.102','2015-02-19 15:51:10','0','0'),
('20','1',' love you not because of who you are, but because of who Iamwhen I am with you.','','0','0','192.168.1.102','2015-02-19 16:23:31','7','0'),
('21','1','自从爱你以后.....才知爱的甜美。','','0','0','192.168.1.102','2015-02-19 16:23:34','0','0'),
('22','1',' 以为没有你，我可以坚强一个人，终于知道我不行。','','0','0','192.168.1.102','2015-02-19 16:23:38','0','0'),
('23','1','走着走着，就散了，回忆都淡了；看着看着，就累了，星光也暗了；听着听着，就醒了，开始埋怨了；回头发现你，不见了，突然我乱了……','','0','0','192.168.1.102','2015-02-19 16:23:41','0','0'),
('24','1','长城的北角边下了一场雨，庄严的历史也有浪漫的痕迹，没有别人语言里的幸福约会地，因为觉得坦然的天地是更长久的秘密，亲爱的，我爱你。','','0','0','192.168.1.102','2015-02-19 16:23:44','0','0'),
('25','1','遇见你是无意，认识你是天意，想着你是情意，不见你时三心二意，见到你便一心一意，如果某天我们有了退意，至少还有回忆！！！','','0','0','192.168.1.102','2015-02-19 16:23:47','0','0'),
('26','1','遇见你是偶然的，喜欢你是自然的，爱上你是毅然的，得到你是欣然的，伴你一生是必然的。','','0','0','192.168.1.102','2015-02-19 16:23:50','0','0'),
('27','1','我现在只想对你说三个字!我爱你!!','','0','0','192.168.1.102','2015-02-19 16:23:52','0','0'),
('28','1','我喜欢你、我们交往吧！','','0','0','192.168.1.102','2015-02-19 16:23:55','2','0'),
('29','1','我的窗口将你目光等待，点燃心中这盏需要爱的未来，照亮心房曾经的徘徊，从此之后没有时间可以停留在那片孤独的沧海，亲爱的，我爱你。','','0','0','192.168.1.102','2015-02-19 16:23:59','0','0'),
('30','1','喂，我看上你了，嫁我呗！','','0','0','192.168.1.102','2015-02-19 16:24:02','0','0'),
('31','1','散落的梧桐叶，洒出一地的金黄，我想牵着你的手，踩着那耀眼的光芒，走向充满甜蜜与幸福的前方。而你，可愿与我一同分享，生命中的每一刻时光？','','0','0','192.168.1.102','2015-02-19 16:24:10','0','0'),
('32','1','让我来照顾你！','','0','0','192.168.1.102','2015-02-19 16:24:13','0','0'),
('33','1','当我女朋友吧，反正又没人要你。 ','','0','0','192.168.1.102','2015-02-19 16:24:16','0','0'),
('34','1','“缘”字有你有我，“爱”字有甜有苦，“情”字有思有恋，“恋”字有喜有悲，“想”字有牵有挂，“你”字是我最关心的朋友，因为你快乐所以我快乐。','','0','0','192.168.1.102','2015-02-19 16:24:18','4','0'),
('35','1','爱人是辛苦的，被爱是幸福的；每个人都幸福地接受着爱，辛苦地爱着人！','','0','0','192.168.1.102','2015-02-19 16:24:21','0','0'),
('36','1','爱是晴天雨天的相扶相伴；是自得潦倒的彼此牵挽；是快活愁烦的分享分忧；爱是我俩之间不变的密意！','','0','0','192.168.1.102','2015-02-19 16:24:24','0','0'),
('37','1','喜欢一个人，是不会有痛苦的。爱一个人，也许有绵长的痛苦， 但他给我的快乐，也是世上最大的快乐。 ','','0','0','192.168.1.102','2015-02-19 16:24:27','0','0'),
('38','1','自从认识了你,疲累、辛苦、紧张、压抑，都远离了我。换来的是对你深深的思念，换来的是对你绵绵的爱恋，还有还有，甜甜的寝食不安、美美的坐卧不宁。','','0','0','192.168.1.102','2015-02-19 16:24:29','1','0'),
('39','1','只因你太美好令我无法坦白说出我爱你。','','0','0','192.168.1.102','2015-02-19 16:24:32','0','0'),
('40','1','做不了你的太阳，就让我做你的影子。','','0','0','192.168.1.102','2015-02-19 16:24:35','0','0'),
('41','1','No man or woman is worth your tears, and the one who is,won‘tmake you cry.','','0','0','192.168.1.102','2015-02-19 16:24:37','0','0'),
('42','1','种下一株合欢花，表白我的心意；弹奏一支相思曲，展露我的诚意；写下一阕蝶恋花，倾诉我的美意；许下一份今世缘，传达我的爱意。','','0','0','192.168.1.102','2015-02-19 16:24:40','0','0'),
('43','1','总是想念着你，虽然我们无法共同拥有每分每秒。','','0','0','192.168.1.102','2015-02-19 16:24:42','0','0'),
('44','1','最遥远的距离不是生与死，而是我站在你面前，你却不知道我爱你。','','0','0','192.168.1.102','2015-02-19 16:24:45','0','0'),
('45','1','自从我第一次遇见你,我就爱上了你.','','0','0','192.168.1.102','2015-02-19 16:24:47','0','0'),
('46','1','You are everything when you are with me, and everything is you when you are not. ','','0','0','192.168.1.102','2015-02-19 16:24:50','4','0'),
('47','1','自从你出现后，我才知道原来有人爱是那么的美好.. ','','0','0','192.168.1.102','2015-02-19 16:24:52','0','0'),
('48','1','左手刻着我，右手写着你，心中充满爱，当我们掌心相对，心心相印时，所有的人都会看到我爱你！','','0','0','192.168.1.102','2015-02-19 16:24:55','0','0'),
('49','1','自见过你那一天，我学会了失眠，不为你的容颜，只忆你的笑脸','','0','0','192.168.1.102','2015-02-19 16:25:05','5','0'),
('50','1','左看，右看，上看，下看，今天就你最耐看;前看，后看，横看，竖看，天下唯你最好看，我宣你！！','','0','0','192.168.1.102','2015-02-19 16:25:08','3','0'),
('51','1','总有一天，你的名字会出现在我家的户口本上。哈哈哈哈','','0','0','192.168.1.102','2015-02-19 16:25:11','0','0'),
('52','1','最想牵的还是你的手，最想念的还是你笑脸，虽然时间改变了我们的容颜，却始终改变不了我爱你的诺言，亲爱的，我爱你，一生不变。','','0','0','192.168.1.102','2015-02-19 16:25:14','0','0'),
('53','1','钻石恒久远，一颗永留传。','','0','0','192.168.1.102','2015-02-19 16:25:17','0','0'),
('54','1','最想看你深情的眼睛，最想听你绵绵的细语，最想摸你温柔的脸颊，最想获取你的真情，最想得到是：你爱我的心。','','0','0','192.168.1.102','2015-02-19 16:25:19','0','0'),
('55','1','幸福是兔子吃胡萝卜，幸福是马儿奔腾，幸福是蜡笔小新看动感超人，幸福是2012世界末日来到之前，和你一起喂兔子，和你策马奔腾，和你一起看蜡笔小新，我爱你！ ','','0','0','192.168.1.102','2015-02-19 16:25:22','0','0'),
('56','1','只是你的声音，我想我已爱上你从我不肯挂电话的那一刻起 ','','0','0','192.168.1.102','2015-02-19 16:25:24','0','0'),
('57','1','、只有你知道我的情绪,也只有你能带给我情绪。','','0','0','192.168.1.102','2015-02-19 16:25:27','3','0'),
('64','1','The worst way to miss someone is to be sitting center besidethemknowing you can‘t have them.',null,'0','0',null,'2015-02-06 14:44:59','8','0'),
('104','1','走吧！去我家！',null,'0','0',null,'2015-02-06 14:44:59','0','0'),
('105','1','我们的距离，只有一颗心的距离，你中有我，我中有你。牵着你的手，赋予我爱情的魔力，对你说着我爱你，一心一意，彼此相惜。',null,'0','0',null,'2015-02-06 14:44:59','4','0'),
('106','1','一生至少该有一次，为了某个人而忘了自己，不求有结果，不求同行，不求曾经拥有，甚至不求你爱我，只求在我最美的年华里，碰到你。',null,'0','0',null,'2015-02-06 14:44:59','0','0'),
('107','1','今天是我们认识的第六十二天。
每一天我都清清楚楚的记得。
每一天我都清清楚楚的记得。',null,'0','0',null,'2015-02-06 14:44:59','0','0'),
('108','1','初见倾心，再见痴心，终日费心，欲得芳心，煞费苦心，想得催心，难道你心，不懂我心！',null,'0','0',null,'2015-02-06 14:44:59','0','0'),
('109','1','不管将来发生什么事，你变成什么样子，你依然是我最爱的。',null,'0','0',null,'2015-02-06 14:44:59','0','0'),
('110','1','爱上了你，我才领略思念的滋味、分离的愁苦和妒忌的煎熬，还有那无休止的占有欲.为什么你的一举一动都让我心潮起伏?为什么我总害怕时光飞逝而无法与你终生厮守?',null,'0','0',null,'2015-02-06 14:44:59','0','0'),
('111','1','爱尔兰有个传说：如果一对恋人彼此离开了对方，天上就有颗星星会熄灭。我希望那颗属于我们的星星永不熄灭，永远闪亮。',null,'0','0',null,'2015-02-06 14:44:59','2','0'),
('112','1','即使你青丝变成白发，我伟岸的身躯不在挺拔；就算我的腿脚不再灵活，你温柔的脸庞已被岁月所刻画；而我们依旧在夕阳下携手！',null,'0','0',null,'2015-02-06 14:44:59','0','0'),
('113','1','当你需要我的时候，我都会在这里；当你有麻烦的时候，我都会在你身边；当你觉得孤独的时候；当你认为所有的人都已绝望；到我这里来，我会给你所有的爱。',null,'0','0',null,'2015-02-06 14:44:59','2','0'),
('114','1','从看到你的那一刻起，我的心跳就告诉我你是我今生等待的人，是你给了我勇气和动力，我会用一生的努力来呵护这份心动的。',null,'0','0',null,'2015-02-06 14:44:59','5','0'),
('115','1','你可以做你自己，那个你说的性格直率，想说就说，想做就做的人。
你不需要再改变了，因为我在改变着自己。',null,'0','0',null,'2015-02-06 14:44:59','3','0'),
('116','1','你可以把我当成一个值得信任的人，当你开心的时候，让我也一起开心。
你可以把我当成一个值得信任的人，当你不开心的时候，让我和你一起分担。',null,'0','0',null,'2015-02-06 14:44:59','0','0'),
('117','1','你不喜欢去的地方，我不会带着你去；你不喜欢做的事，我不会逼你；你不喜欢我任性，我不会再任性；当你不想我烦着你的时候，我会静静的站在一旁，我送你的礼物，你不喜欢，我不会勉强你。',null,'0','0',null,'2015-02-06 14:44:59','5','0'),
('118','1','真爱是无敌的，这是一个爱情真理。只要一个人的心中有爱，就没有是不可能战胜的。怕只怕不敢去爱，一旦你勇敢的爱下去，就没有什么事是你不可能完成的。',null,'0','0',null,'2015-02-06 14:44:59','11','0'),
('119','1','花还未落，树怎敢死，你还未嫁，我怎敢老。愿你能陪我相守天涯。',null,'0','0',null,'2015-02-06 14:44:59','18','0'),
('120','1','如果我能拥有这份荣幸，我愿终身陪伴着你，一年四季陪伴着你。',null,'0','0',null,'2015-02-06 14:44:59','6','0'),
('124','1','当我们都不在那么年轻的时候，才发现原来我们的心是相通的，当年我们缺的只是一次表白的机会，我想说我喜欢你。','司云轩','0','0','0:0:0:0:0:0:0:1','2015-02-26 12:36:06','17','0'),
('129','1','当你难过的时候，我希望能陪在你身边，尽全力让你笑起来。我不知道遇见你是对是错，但我知道遇见你我开心过。','','0','0','192.168.216.176','2015-03-01 20:11:03','18','0'),
('130','1','有时候我真想忘了你，只记得这个世界，然而，我常常忘了整个世界，只记得你。','','0','0','192.168.216.176','2015-03-01 20:11:39','17','0'),
('132','1','世界太大，人海茫茫，总是遇不见那个对的人；世界又太小，芸芸众生，纵使有很多分岔口，总是会在终点遇见那个对的人。想对你说：亲爱的，是天定，让你我相遇、相爱、相伴，我们会一直恩爱幸福到老！','','0','0','192.168.216.118','2015-03-02 12:48:44','23','0'),
('134','1','气你，逗你，只因喜欢你；学你，跟你，只因爱上你；疼你，顺你，只因想追你；想你，爱你，只想亲亲你；疼你，懂你，只想问问你，可否一生与我在一起。','','0','0','10.123.43.240','2015-03-02 19:29:17','29','0'),
('135','1','其实，爱，不过是在繁华落尽后留在身边的那一个。你愿意与我一起去看那细水长流么？','','0','0','10.123.43.240','2015-03-02 19:39:46','21','0'),
('136','1','一个人的情人节并不孤独，想一个人的时候才会孤独。远处灯光，是我祝福你的目光。既使相隔千万年，仍执迷不悟地守候在你的心外，等你把我领进来。','','0','0','10.123.43.240','2015-03-02 19:40:31','34','0'),
('137','1','曾经有一份真诚的爱情放在我面前，我没有珍惜，等我失去的时候我才后悔莫及，人世间最痛苦的事莫过于此。你的剑在我的咽喉上割下去吧！不用再犹豫了！',null,'0','0',null,'2015-03-02 20:46:47','31','0'),
('138','1','如果上天能够给我一个再来一次的机会，我会对那个女孩子说三个字：我爱你。如果非要在这份爱上加上一个期限，我希望是一万年',null,'0','0',null,'2015-03-10 20:46:54','115','2'),
('139','26','二蛋，请允许我这么称呼你，虽然现在我还没有这样的资格。孩子我会负责的。','二蛋','0',null,'122.194.216.250','2015-03-14 21:01:22','54','1'),
('140','26','钊钊，在我们被分到同一寝室的时候，我就知道我会爱上你，只因对的时间，对的地点','小钊','4','0','221.178.189.239','2015-03-16 19:42:03','51','2'),
('141','1','能够遇见你,对我来说是最大的幸福。有了你,我的生活变的无限宽广,有了你,世界变得如此迷人。Love you forever!','云轩','0',null,'221.178.189.231','2015-03-16 19:47:11','40','0'),
('142','1','缘是美丽的邂逅，爱是心跳的感觉，情是心灵的交会，恋是甜蜜的思念，走在爱与被爱的边缘，你见或者不见，爱你的心始终不改变！八戒，Love You!!!','八戒','0','0','122.194.216.251','2015-03-16 22:16:16','84','3'),
('143','27','风吹起了从前
你如水的容颜
摇摇晃晃像盛开的睡莲
大雨滴落在昨天
你回首的那瞬间
多少爱恋
想要让你看得见','王勇智','6','1','221.6.38.38','2015-03-16 22:40:19','165','7'),
('144','1','不怕爱错，只怕没爱过。爱尔兰有个传说：如果一对恋人彼此离开了对方，天上就有颗星星会熄灭。我希望那颗属于我们的星星永不熄灭，永远闪亮。司云轩，love you forever.....','云轩','0',null,'122.194.216.253','2015-03-18 22:48:11','98','0'),
('146','26','难忘的是你胖胖的，白白的脸蛋。萦绕着的是你甜甜的笑容。也许多少年后，依然会想起，那年，那场雪，那个冬天，那年少的梦。','小兔','0',null,'122.194.216.252','2015-03-22 23:16:26','54','0'),
('147','30','喜欢你帅气的脸庞，迷恋你性感的身材。你充满磁性的声音，每次听到都让我心潮澎湃。我爱你，无法自拔。即使是迷失，我也心甘情愿。','司云轩','0','1','58.192.8.112','2015-03-22 23:30:24','86','0'),
('148','1','能够遇见你,对我来说是最大的幸福。有了你,我的生活变的无限宽广,有了你,世界变得如此迷人。你是世界,世界是你。我愿意用自己的心,好好的陪着你。兔兔，I love you.','司云轩','0',null,'221.181.237.131','2015-03-23 23:15:28','83','0'),
('149','1','还记得那场音乐会的烟火，还记得那个凉凉的深秋，还记得人潮把你推向了我，游乐园拥挤的正是时候，一个夜晚坚持不睡的等候，一起泡温泉奢侈的享受，有一次日记里愚蠢的困惑，因为你的微笑幻化成风。','司云轩','0',null,'122.194.216.252','2015-04-07 12:09:48','56','1'),
('150','14','我不是碰不到更好的，而是因为有了你，我不想碰见更好的；我不是不会对别人动心，而是因为有了你，我觉得没有必要再对其他人动心；我不是不会爱上别人，而是我学会更加珍惜你。世界上好人数不清，但我有你就够了！','200','0',null,'221.178.189.250','2015-04-10 19:14:58','62','3'),
('151','31','那些分手后还保持联络的，要么当初不够爱，要么不甘心，还试图保留一点残余的暧昧吧。当初若爱得刻骨，分手后必定形同陌路。你我无关，这是对逝去的真爱唯一的祝福。','','0',null,'221.15.252.248','2015-04-13 20:48:05','67','1'),
('152','1','回忆青春感觉总是美好的，因为在回忆中会增强美好的部分，但真当我们经历的时候可能就感觉缺少那份美好。所以现在我们能做的就是享受现在的生活，生活随意点！加油','王勇智','0','1','58.192.8.124','2015-04-13 23:06:45','70','0'),
('153','1','黄磊在他的似水年华中的独白中说道：“我希望我得到的少一点，再少一点；生命短一些，再短一些。”人性都是贪婪的，人也都是畏惧死亡的，当把一切都看淡一些的时候，我想什么都显得不那么重要了。','王勇智','0',null,'122.194.216.252','2015-04-15 23:30:18','63','0'),
('155','1','走着走着就散了，回忆都淡了，回头发现你不见了，忽然我乱了。时间有时真是个好东西，让你不知不觉间忘掉过去的伤痛，一直催使你前进。去享受当下的生活，努力让自己变得更好！加油！','王勇智','4',null,'221.178.189.241','2015-04-18 18:42:43','76','0'),
('156','33','喜欢你喜欢你喜欢就是喜欢你不知道为什么就是喜欢你！','她','0',null,'101.204.5.114','2015-04-26 10:21:18','74','1'),
('157','35','你以前追我的时候，我没有接。追了我两年吧 因为这两年来，我伤心的时候你逗我笑，每天关心我。我已经渐渐习惯有你在我身边了。可是你那天发来消息，你说你接受了一个女孩子，我哭了。发现自己已经喜欢上你了 ','baby’breath','0','1','182.84.25.20','2015-05-02 19:02:11','82','2'),
('158','38','本来想要和你成为恋人，可最终选择了和你做兄妹，但我会一直一直的喜欢着你的！','何宇健','6',null,'223.73.189.176','2015-05-08 21:34:08','77','2'),
('159','1','你要相信这个世界上一定有一个人，ta会穿越茫茫的人流、怀着沉甸甸的爱和满腔的热情走进你、抓紧你，只是你要等。而在等待的过程中我们要让自已变得更好。因为你喜欢的那个人一定会在你变得更好的路上和你相遇。','王勇智','0',null,'58.192.8.253','2015-05-09 22:48:04','56','0'),
('160','38','你早就知道我是谁，你说你不想说，因为想让我去找你，你不知道你说这段话我多么心动，我喜欢你！','何大大','0',null,'223.73.127.192','2015-05-13 20:00:53','68','1'),
('161','38','回头看到故意你走在我后面，你的呼吸我都听得见，我的心扑通扑通的跳，你是不知道了我的心意，我喜欢你！','何大大','0',null,'223.73.127.192','2015-05-14 21:59:35','64','1'),
('162','1','在你以后的日子里，我希望能够有我的陪伴，和你一起散步，黄昏漫步在操场上，我们手牵手就这么一直走下去。我能想到最浪漫的事，
就是和你一起慢慢变老。','王勇智','0',null,'223.67.207.239','2015-05-23 12:16:08','71','0'),
('163','38','还有三十五天了，我们要分开了，怎么办、以后连偷看你的机会都没有了、我想在我要离开的时候，请答应做我七天男友，哪怕一天也行、让我没有遗憾的离开，我喜欢你!','何宇健','0',null,'223.73.127.105','2015-05-27 21:43:48','62','0'),
('164','48','  你问我为什么喜欢你，我只能说：因为是你，因为是我，所以我爱你！就让我们牵着手到最后','','0',null,'27.9.241.162','2015-05-28 22:30:53','59','1'),
('165','49','闺蜜：我爱你，你是我这辈子最爱的女人。
','','0',null,'115.56.62.22','2015-05-29 21:22:53','52','0'),
('166','51',' 我爱你已经成了笑话，','李晓琪','0',null,'124.134.178.28','2015-06-06 15:32:02','46','1'),
('167','38','你越来越在乎我、我更是爱你越来越无法自拔、我永远都喜欢着你！','何宇键','6',null,'223.73.189.218','2015-06-07 17:47:16','39','1'),
('168','1','我们总是在后知后觉中经历着人生，失去过才懂得拥有过的美好。不管如何，珍惜现在拥有的，享受现在的生活，加油！','王勇智','0',null,'221.178.188.205','2015-06-10 23:20:56','30','0'),
('169','1','十七八岁的年纪遇到了不可能在一起的人，却还是拼尽全力去爱，如今才刚刚二十岁出头风华正茂，却丧失了爱一个人的能力。','王勇智','6',null,'183.206.84.35','2015-06-13 08:26:07','48','0'),
('170','1','有一天当你穿上西装成为别人的新郎，我会闭口不提曾经的疯狂,
；有一天我穿上婚纱成为别人的新娘，你依旧是我最初的梦想！','王勇智','0',null,'58.192.8.29','2015-06-14 12:28:21','43','0'),
('171','1','记住该记住的，忘记该忘记的，改变能改变的，接受不能改变的。待到铅华洗尽，回首往事，自己奋斗过，不留太多的遗憾。','王勇智','6',null,'223.67.207.84','2015-06-21 08:56:23','64','2'),
('172','53','一直，一直喜欢冬冬。永远，永远最喜欢冬冬了QAQ最喜欢...永远最喜欢....小樱永远最喜欢冬冬了QAQ冬冬DAI SU KI.','冬冬','0',null,'220.163.196.106','2015-06-21 22:26:30','42','2'),
('173','53','谢谢你 曾经 给了我整个世界。一直以来，谢谢你了！最喜欢你了！','冬冬','0',null,'220.163.196.106','2015-06-21 22:30:02','48','1'),
('176','1','你，我一生最爱的人；你，我一生最想的人；你，我愿守候一生的人。是你给了我勇气和动力，我会用一生的努力来呵护这份心动的！','王勇智','0',null,'223.67.207.192','2015-07-05 13:48:30','11','0');
DROP TABLE IF EXISTS  `t_replay`;
CREATE TABLE `t_replay` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `Title` varchar(100) DEFAULT NULL COMMENT '题目',
  `Content` longtext COMMENT '内容',
  `FaceIcon` varchar(100) DEFAULT NULL COMMENT '表情地址',
  `PostTime` datetime DEFAULT NULL COMMENT '回复时间',
  `IpAddress` varchar(50) DEFAULT NULL COMMENT '回复者Ip地址',
  `IsDelete` int(11) DEFAULT NULL COMMENT '是否删除',
  `ReplayUserId` bigint(20) DEFAULT NULL COMMENT '回复者的编号',
  `TopicId` bigint(20) DEFAULT NULL COMMENT '外键--回复对应的表白',
  PRIMARY KEY (`Id`),
  KEY `Topic` (`TopicId`),
  KEY `ReplayUser` (`ReplayUserId`),
  CONSTRAINT `ReplayUser` FOREIGN KEY (`ReplayUserId`) REFERENCES `t_user` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `Topic` FOREIGN KEY (`TopicId`) REFERENCES `t_releasecontent` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8;

insert into `t_replay`(`Id`,`Title`,`Content`,`FaceIcon`,`PostTime`,`IpAddress`,`IsDelete`,`ReplayUserId`,`TopicId`) values
('1','h哈哈','我喜欢你','1','2015-02-11 16:31:21','127.0.0.1','0','1','1'),
('2','呵呵呵','I Love You','1','2015-02-17 18:05:51','127.0.0.1','0','6','1'),
('3','哈哈哈','<span style="font-size: 16px;">&nbsp;我想你</span>','2','2015-02-12 21:33:45','0:0:0:0:0:0:0:1',null,'1','1'),
('4','王勇智','&nbsp;我宣你','3','2015-02-12 21:45:29','0:0:0:0:0:0:0:1',null,'1','1'),
('5','王勇智','&nbsp;我宣你','3','2015-02-12 21:46:29','0:0:0:0:0:0:0:1',null,'1','1'),
('6','123','&nbsp;123123','2','2015-02-12 21:47:14','0:0:0:0:0:0:0:1',null,'1','1'),
('7','王大侠','萌萌哒','2','2015-02-12 22:05:55','172.20.10.2',null,'1','1'),
('8','大蝈蝈','&nbsp;银价就是宣你啦','9','2015-02-12 22:09:26','172.20.10.2',null,'1','1'),
('9','大镁铝','&nbsp;宣你<img src="http://mrwang:8080/VindicateWallProj/fckeditor/editor/images/smiley/wangwang/4.gif" alt="" />','1','2015-02-12 22:18:19','172.20.10.2',null,'1','1'),
('10','','&nbsp;123123213','1','2015-02-19 22:35:13','192.168.1.102',null,'1','113'),
('11','','&nbsp;啊实打实的','1','2015-02-19 23:07:39','192.168.1.102',null,'1','1'),
('12','','&nbsp;啊实打实的','1','2015-02-19 23:07:46','192.168.1.102',null,'1','1'),
('13','','&nbsp;啊实打实的','1','2015-02-19 23:07:54','192.168.1.102',null,'1','1'),
('14','','&nbsp;委屈','1','2015-02-19 23:08:09','192.168.1.102',null,'1','1'),
('15','','&nbsp;趣味','1','2015-02-19 23:11:21','192.168.1.102',null,'1','1'),
('16','','&nbsp;趣味','1','2015-02-19 23:15:18','192.168.1.102',null,'1','1'),
('17','','&nbsp;趣味','1','2015-02-19 23:15:30','192.168.1.102',null,'1','1'),
('18','','&nbsp;趣味','1','2015-02-19 23:16:20','192.168.1.102',null,'1','1'),
('19','','&nbsp;12333','1','2015-02-20 22:46:34','0:0:0:0:0:0:0:1',null,'1','1'),
('20','','&nbsp;去问去问','1','2015-02-20 22:48:39','0:0:0:0:0:0:0:1',null,'6','1'),
('21','楼主威武','','1','2015-03-11 21:04:48','221.181.237.150',null,'1','138'),
('22','萌萌哒','&nbsp;萌萌哒','1','2015-03-12 14:05:19','221.181.237.148',null,'1','137'),
('23','','楼主"S"+"B";','1','2015-03-14 20:57:34','221.181.237.133',null,'26','138'),
('24','楼主是个大傻x','&nbsp;楼主是个大傻x<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/32.gif" alt="" />','1','2015-03-14 21:11:56','221.181.237.155',null,'1','139'),
('25','楼主V5','楼主威武霸气<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/12.gif" alt="" />','1','2015-03-16 19:43:40','221.178.189.239',null,'1','140'),
('26','','讨厌','12','2015-03-16 22:18:15','221.6.38.38',null,'27','142'),
('27','哈哈','&nbsp;<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/7.gif" alt="" />','1','2015-03-16 22:20:01','221.181.237.157',null,'1','142'),
('28','','&nbsp;为嘛我的都是小表情，你的是大表情<br />
<br type="_moz" />','1','2015-03-16 22:25:12','221.6.38.38',null,'27','142'),
('29','','<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/1.gif" alt="" />&nbsp;','1','2015-03-16 22:30:51','221.6.38.38',null,'27','142'),
('30','楼主不要酱紫嘛','<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/4.gif" alt="" />多不好腻死<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/86.gif" alt="" />&nbsp;','6','2015-03-16 22:42:44','221.181.237.157',null,'1','143'),
('31','','纳尼，竟然没听这首歌<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/33.gif" alt="" />','1','2015-03-16 22:45:10','221.6.38.38',null,'27','143'),
('32','木有。。。','<span style="font-size: 20px;">还真木有听过<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/30.gif" alt="" /></span>','1','2015-03-16 22:48:08','221.181.237.133',null,'1','143'),
('33','哈哈','<span style="font-size: 36px;">yeah<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/20.gif" alt="" /></span>','1','2015-03-16 22:49:47','221.181.237.141',null,'1','142'),
('34','哈哈','<span style="font-size: 36px;">yeah<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/20.gif" alt="" /></span>','1','2015-03-16 22:49:47','221.181.237.141','1','1','142'),
('35','','<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/42.gif" alt="" />&nbsp;表情包很丰富','1','2015-03-16 22:56:40','221.6.38.38',null,'27','143'),
('36','','&nbsp;勇智他哥<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/16.gif" alt="" />','1','2015-03-16 22:59:17','221.6.38.38',null,'27','138'),
('37','yeah','&nbsp;棒棒哒<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/79.gif" alt="" />','1','2015-03-16 23:05:07','58.192.8.171',null,'1','143'),
('38','','&nbsp;','1','2015-03-17 23:32:14','122.194.216.250',null,'28','143'),
('39','','<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/3.gif" alt="" />&nbsp;','1','2015-03-17 23:32:33','122.194.216.250',null,'28','143'),
('40','','&nbsp;','1','2015-03-17 23:33:51','122.194.216.250',null,'28','3'),
('41','','&nbsp;于航哪位<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/0.gif" alt="" />','1','2015-03-18 12:06:10','58.192.8.115',null,'1','143'),
('42','','&nbsp;我也是醉啦！你玩的好开心啊','1','2015-03-18 19:05:57','221.178.189.251',null,'14','140'),
('43','good','棒棒哒<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/12.gif" alt="" />','1','2015-03-19 13:10:16','122.194.216.254',null,'1','144'),
('44','','<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/18.gif" alt="" />&nbsp;','1','2015-03-19 21:13:39','221.6.38.38',null,'27','143'),
('45','','&nbsp;哈哈','1','2015-03-27 22:37:21','221.181.237.132',null,'1','148'),
('46','棒棒哒','威武霸气','1','2015-04-07 12:11:14','122.194.216.252',null,'1','149'),
('47','','<span style="font-size: 16px;">&nbsp;楼主说的好有道理<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/0.gif" alt="" /></span>','1','2015-04-13 22:52:23','122.194.216.254',null,'1','151'),
('48','','呵呵哒','1','2015-04-13 22:57:00','122.194.216.254',null,'1','150'),
('49','','&nbsp;好晚的说','1','2015-04-13 23:07:15','58.192.8.124',null,'1','152'),
('50','','&nbsp;棒棒嗒<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/0.gif" alt="" />','1','2015-04-18 18:43:33','221.178.189.250',null,'1','155'),
('51','','&nbsp;棒棒嗒<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/0.gif" alt="" />','1','2015-04-18 18:44:21','221.178.189.238',null,'1','155'),
('52','','楼主是在说我么
','1','2015-04-20 23:53:02','58.192.8.245',null,'30','149'),
('53','加油','good<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/16.gif" alt="" />','1','2015-04-21 10:27:45','221.178.189.247',null,'1','153'),
('54','','<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/0.gif" alt="" />&nbsp;','1','2015-04-27 22:23:51','221.178.189.249',null,'1','156'),
('55','','&nbsp;<span style="font-size: 16px;">楼主那就说明啊，不要有遗憾</span><img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/0.gif" alt="" />','1','2015-05-02 23:08:24','122.194.216.253',null,'1','157'),
('56','','&nbsp;其实有时候得到了并不一定就是好的，所以 还是可以选择其他方式的','1','2015-05-09 16:28:32','183.206.84.17',null,'14','158'),
('57','','<span style="font-size: 16px;">爱要大声说出来，说不定就成了呢<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/11.gif" alt="" /></span>','4','2015-05-09 22:35:17','122.194.216.253',null,'1','158'),
('58','','<span style="font-size: 20px;">等待中要学会享受孤独，会让你变的更好！<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/0.gif" alt="" /></span>','1','2015-05-09 22:53:44','221.178.189.245',null,'1','159'),
('59','','&nbsp;棒棒哒<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/67.gif" alt="" />','1','2015-05-14 12:02:20','221.178.189.246',null,'1','160'),
('60','','<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/0.gif" alt="" />','1','2015-05-15 21:57:03','221.178.189.251',null,'1','161'),
('61','','<span style="font-size: 20px;">相信你的爱人正在未来的某个拐角等你</span>','1','2015-05-23 12:22:33','223.67.207.239',null,'1','162'),
('62','','棒棒哒','1','2015-05-29 12:08:23','122.194.216.253',null,'1','164'),
('63','','&nbsp;哈哈哈哈','1','2015-06-07 22:33:48','221.178.188.206',null,'1','167'),
('64','','爱是没有笑话的','1','2015-06-07 22:34:10','221.178.188.206',null,'1','166'),
('65','','&nbsp;楼主棒棒哒','1','2015-06-10 23:24:50','221.178.188.205',null,'1','168'),
('66','','&nbsp;哈哈哈','1','2015-06-10 23:24:56','221.178.188.205',null,'1','168'),
('67','','盗窃','1','2015-06-13 08:26:44','183.206.84.35',null,'1','169'),
('68','','&nbsp;哈哈哈哈哈<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/8.gif" alt="" />','1','2015-06-21 09:00:24','223.67.207.84',null,'1','171'),
('69','','&nbsp;哈哈哈哈哈<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/8.gif" alt="" />','1','2015-06-21 09:05:32','223.67.207.84',null,'1','171'),
('70','','&nbsp;可是你怎么知道什么是能改变的呢？','14','2015-06-21 22:16:18','221.181.237.140',null,'14','171'),
('71','','小樱不应该喜欢佐助吗<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/3.gif" alt="" />','1','2015-06-22 11:05:38','223.67.207.223',null,'1','172'),
('72','','&nbsp;不客气，多大点事<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/74.gif" alt="" />','1','2015-06-22 11:06:26','223.67.207.223',null,'1','173'),
('74','回复三楼','<span style="font-size: 20px;">当你尽全力去做之后，即使没有改变，但未来的自己可以说，我不后悔，我努力坚持过。</span>','1','2015-07-02 15:59:11','122.194.216.254',null,'1','171'),
('75','','楼主好帅<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/7.gif" alt="" />','1','2015-07-03 14:08:30','122.194.216.253',null,'1','171'),
('76','','楼主帅气<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/4.gif" alt="" />','1','2015-07-03 14:11:01','122.194.216.253',null,'55','171'),
('77','','不要和我抢<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/24.gif" alt="" />','1','2015-07-03 14:12:50','122.194.216.253',null,'1','172'),
('78','','&nbsp;哈哈哈哈','1','2015-07-03 23:30:05','122.194.216.251',null,'1','143'),
('79','','棒棒哒<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/12.gif" alt="" />','1','2015-07-03 23:32:09','122.194.216.251',null,'1','150'),
('80','','哈哈哒<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/3.gif" alt="" />','1','2015-07-05 00:01:59','122.194.216.250',null,'1','150'),
('81','','<span style="font-size: 20px;">楼主真棒！<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/67.gif" alt="" /></span>','1','2015-07-05 13:49:34','223.67.207.192',null,'1','176'),
('82','','棒棒哒<img src="http://www.bravetolove.com/fckeditor/editor/images/smiley/wangwang/0.gif" alt="" />','1','2015-07-05 14:01:21','223.67.207.192',null,'1','157');
DROP TABLE IF EXISTS  `t_user`;
CREATE TABLE `t_user` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `UserName` varchar(20) NOT NULL COMMENT '用户名',
  `Password` varchar(50) NOT NULL COMMENT '用户密码',
  `RealName` varchar(20) DEFAULT NULL COMMENT '真实姓名',
  `Sex` varchar(10) DEFAULT NULL COMMENT '性别',
  `Email` varchar(20) DEFAULT NULL COMMENT '邮箱',
  `Birthday` date DEFAULT NULL COMMENT '出生日期',
  `Telphone` varchar(20) DEFAULT NULL COMMENT '手机号码',
  `QQ` varchar(20) DEFAULT NULL COMMENT 'qq号码',
  `UserLevel` int(11) DEFAULT '1' COMMENT '账号等级',
  `SafeQuestion` text NOT NULL COMMENT '安全问题',
  `SafeAnswer` varchar(50) NOT NULL COMMENT '问题答案',
  `IsUsable` int(11) DEFAULT '1' COMMENT '是否可用（1可用，0禁用）',
  `MsgCount` int(11) DEFAULT '0' COMMENT '消息条数',
  `FaceImage` varchar(100) DEFAULT NULL COMMENT '头像',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;

insert into `t_user`(`Id`,`UserName`,`Password`,`RealName`,`Sex`,`Email`,`Birthday`,`Telphone`,`QQ`,`UserLevel`,`SafeQuestion`,`SafeAnswer`,`IsUsable`,`MsgCount`,`FaceImage`) values
('1','莫失莫忘','8ca94f23a297258e52c2db7dbafc4a47','王勇智','女','12312312@qq.com','2015-03-18','18360539986','849451478','5','父亲姓名','123','1','17',null),
('6','莫失&莫忘','202cb962ac59075b964b07152d234b70','123',null,'123',null,'','','0','父亲姓名','123','1','1',null),
('13','lawliet','8ca94f23a297258e52c2db7dbafc4a47','','男','',null,'','','0','父亲姓名','王道喜','1','5',null),
('14','宛沁汐','661121c109969b7bb681bfe7916fe844','','女',null,null,null,null,'2','最擅长做的菜','土豆丝','1','3',null),
('15','xwe','e1b91209a1eff65f9665de89e8643fed','李晨','男',null,null,null,null,'0','父亲姓名','行为','1','1',null),
('16','王勇智1','66b51cdb0baf194db081053db6750254','王勇智','男',null,null,null,null,'0','父亲姓名','1','1','5',null),
('17','王用纸','4dbfcfc131465396526085ae63f963b8','王用纸','男',null,null,null,null,'0','对你影响最大的人的姓名','王用纸','1','1',null),
('21','莫莫莫','4297f44b13955235245b2497399d7a93','123','女',null,null,null,null,'0','父亲姓名','123','1','0',null),
('22','测试1','4297f44b13955235245b2497399d7a93','123','男',null,null,null,null,'0','父亲姓名','123123','1','5',null),
('23','测试2','4297f44b13955235245b2497399d7a93','wang','男',null,null,null,null,'0','父亲姓名','123123','1','5',null),
('24','测试3','4297f44b13955235245b2497399d7a93','wang','男',null,null,null,null,'0','父亲姓名','123123','1','0',null),
('25','测试4','4297f44b13955235245b2497399d7a93','wang','男',null,null,null,null,'0','父亲姓名','123123','1','1',null),
('26','勇智他哥','cc6313f041af7a415183268f20c15e73','云轩','男',null,null,null,null,'5','初恋的姓名','燕燕','1','2',null),
('27','月满西楼','dcdc7da52e5a29643ea9b00e0889216d','李修寒','男',null,null,null,null,'1','高中班主任','老杨','1','2',null),
('28','于航0840','8fc4f14bf2c0485fea27468a0ed20856','于航','男',null,null,null,null,'0','高中班主任','牟君臣','1','1',null),
('29','。执子之手。','460841dcf3b9e044d0ae81eef708d8ee','','女',null,null,null,null,'0','最擅长做的菜','只会吃','1','1',null),
('30','信徒不苦','cc6313f041af7a415183268f20c15e73','司云轩','男',null,null,null,null,'5','初恋的姓名','燕燕','1','4',null),
('31','张无忌','e10adc3949ba59abbe56e057f20f883e','张无忌','男',null,null,null,null,'0','父亲姓名','你猜','1','1',null),
('32','123123','4297f44b13955235245b2497399d7a93','123','男',null,null,null,null,'0','父亲姓名','123','1','1',null),
('33','Arui','7479d1d197566fa9fdb58c33337b892e','','男',null,null,null,null,'0','父亲姓名','爸爸','1','0',null),
('34','love0223','d6804d27e2d5ddfb4321e45c6708624e','柴大大','男','','1993-02-23','','754621997','0','对你影响最大的人的姓名','柴玉帅','1','0',null),
('35','不想回忆过去！！','ce73729da2f965fd6f7feb4ffbc6527e','夔隆蛊孽','女',null,null,null,null,'0','对你影响最大的人的姓名','何瑞星','1','1',null),
('36','测试5','200820e3227815ed1756a6b531e7e0d2','王','男',null,null,null,null,'0','父亲姓名','123','1','1',null),
('37','爱smb1314','edcdd6c900638f74ac637e52a66c0ea6','肖wj','男',null,null,null,null,'0','初恋的姓名','单梦博','1','1',null),
('38','安锦流年、','f6021cc3a63e89188cf8f24a20172aa1','黎麻麻','女','','2000-02-12','','2413942108','1','对你影响最大的人的姓名','何大大、','1','1',null),
('39','墨香豆','200820e3227815ed1756a6b531e7e0d2','萤火虫','女',null,null,null,null,'0','高中班主任','李志锋','1','1',null),
('40','墨香豆','200820e3227815ed1756a6b531e7e0d2','萤火虫','女',null,null,null,null,'0','高中班主任','李志锋','1','0',null),
('41','陈翔是我脑公','26e6c43dd7b43986a0b66098cb679b63','','女',null,null,null,null,'0','对你影响最大的人的姓名','自己','1','1',null),
('42','谁为谁流泪，谁为谁心碎。','a74298e4a259759687e3a5acb2e7ae12','钟琦慧','女',null,null,null,null,'0','父亲姓名','钟绍坚','1','0',null),
('43','谁为谁流泪，谁为谁心碎。','a74298e4a259759687e3a5acb2e7ae12','钟琦慧','女',null,null,null,null,'0','父亲姓名','钟绍坚','1','0',null),
('44','谁为谁流泪，谁为谁心碎。','a74298e4a259759687e3a5acb2e7ae12','钟琦慧','女',null,null,null,null,'0','父亲姓名','钟绍坚','1','0',null),
('45','谁为谁流泪，谁为谁心碎。','a74298e4a259759687e3a5acb2e7ae12','钟琦慧','女',null,null,null,null,'0','父亲姓名','钟绍坚','1','0',null),
('46','独一无二','b6b675e2cdee4d4692551292d509b5e8','谢龙科','男',null,null,null,null,'0','对你影响最大的人的姓名','谢','1','0',null),
('47','TiffanyUChen','16ba4c5238d252ae476e1acd79cfb0c2','','女','1270173748@qq.com',null,'18861330583','1270173748','0','对你影响最大的人的姓名','宋贞波','1','1',null),
('48','是你是我','2c938f3e30aeec79f99bd326838f062b','陈华','男',null,null,null,null,'0','初恋的姓名','余敏','1','0',null),
('49','离人怎挽i','a8eea1253a1f5eea6e53a2cda5709d91','王冠琛','男','','2001-10-29','','507272165','0','初恋的姓名','没有','1','1',null),
('50','丿Love丶雅','cd24ebc620ca6bd5c141440bdbc2e63f','小雅','女','3044227881@qq.com','1999-06-17','','3044227881','0','对你影响最大的人的姓名','鱼腾腾','1','0',null),
('51','小阳哥丶','91962946a45c403b747f22201a6489fd','綦敬祥','男',null,null,null,null,'0','高中班主任','...','1','0',null),
('52','test','4297f44b13955235245b2497399d7a93','123123','男',null,null,null,null,'0','父亲姓名','123','1','1',null),
('53','全世界最喜欢冬冬的小樱','23f44b446e905ed8326971bc691b663c','木之本樱','女','','2001-05-03','','','0','初恋的姓名','杨冬','1','1',null),
('54','444','73882ab1fa529d7273da0db6b49cc4f3','444','女',null,null,null,null,'0','初恋的姓名','444','1','1',null),
('55','adminTest','72adc15352810c6d960fea7edb398c77','测试专用','男',null,null,null,null,'0','父亲姓名','123','1','1',null);
DROP TABLE IF EXISTS  `tb_manageuser`;
CREATE TABLE `tb_manageuser` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `UserName` varchar(20) DEFAULT NULL COMMENT '管理员用户名',
  `Password` varchar(50) DEFAULT NULL COMMENT '管理员密码',
  `UserType` varchar(20) DEFAULT NULL COMMENT '管理员类型',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

insert into `tb_manageuser`(`Id`,`UserName`,`Password`,`UserType`) values
('1','莫失莫忘','b04af6f645de5683f2801a7d80c94704','超级管理员'),
('3','王勇智','4297f44b13955235245b2497399d7a93',null),
('4','宛沁汐','661121c109969b7bb681bfe7916fe844','超级管理员');
DROP TABLE IF EXISTS  `tb_manageuser_role`;
CREATE TABLE `tb_manageuser_role` (
  `UserId` int(11) NOT NULL COMMENT '用户编号',
  `RoleId` int(11) NOT NULL COMMENT '角色编号',
  PRIMARY KEY (`RoleId`,`UserId`),
  KEY `UId` (`UserId`),
  KEY `RId` (`RoleId`) USING BTREE,
  CONSTRAINT `RoleId` FOREIGN KEY (`RoleId`) REFERENCES `tb_role` (`Id`),
  CONSTRAINT `UId` FOREIGN KEY (`UserId`) REFERENCES `tb_manageuser` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into `tb_manageuser_role`(`UserId`,`RoleId`) values
('1','1'),
('3','5'),
('4','1');
DROP TABLE IF EXISTS  `tb_privilege`;
CREATE TABLE `tb_privilege` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `Url` varchar(255) DEFAULT NULL COMMENT '对应的url地址',
  `Name` varchar(50) DEFAULT NULL COMMENT '对应名称',
  `ParentId` int(11) DEFAULT NULL COMMENT '上级编号',
  PRIMARY KEY (`Id`),
  KEY `parentId` (`ParentId`) USING BTREE COMMENT '上级编号索引',
  CONSTRAINT `parent` FOREIGN KEY (`ParentId`) REFERENCES `tb_privilege` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

insert into `tb_privilege`(`Id`,`Url`,`Name`,`ParentId`) values
('1',null,'系统管理',null),
('2',null,'系统日志','1'),
('3','/user_list','前台用户管理','1'),
('4','/user_list','前台用户列表','3'),
('5','/user_delete','前台用户删除','3'),
('6','','后台管理',null),
('7','/manageUser_list','后台用户列表','6'),
('8','/manageUser_delete','后台用户删除','7'),
('9',null,'后台用户修改','7'),
('10',null,'表白管理',null),
('11','/vindicate_list','表白内容管理','10'),
('12','/adminReplay_list','表白回复管理','10'),
('13','/user_returnBefore','前台用户还原','3'),
('14','/vindicate_list','表白内容列表','11'),
('15','/vindicate_delete','表白内容删除','11'),
('16','/adminReplay_list','回复内容列表','12'),
('17','/adminReplay_delete','回复内容不显示','12'),
('18','/vindicate_recommand','表白推荐','11'),
('19','/vindicate_returnBefore','表白推荐恢复','11'),
('20','/adminReplay_returnBefore','恢复还原','12'),
('21','/manageUser_initPassword','后台用户重置密码','7'),
('22',null,'网站问题',null),
('23','/adminProblem_list','网站问题列表','22'),
('24','/adminProblem_delete','网站问题删除','23'),
('25','/sysInfo_list','系统消息管理','1'),
('26','/role_list','角色管理','6'),
('27','/role_list','角色列表','26'),
('28','/role_edit','角色编辑','26'),
('29','/role_delete','角色删除','26'),
('30','/role_add','角色添加','26'),
('31','/adminDailyVin_list','每日表白管理','10'),
('32','/adminDailyVin_list','每日表白列表','31'),
('33','/adminDailyVin_delete','每日表白删除','32'),
('34','/adminDailyVin_edit','每日表白修改','32');
DROP TABLE IF EXISTS  `tb_role`;
CREATE TABLE `tb_role` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `Name` varchar(50) DEFAULT NULL COMMENT '角色名称',
  `Description` varchar(255) DEFAULT NULL COMMENT '角色描述',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

insert into `tb_role`(`Id`,`Name`,`Description`) values
('1','超级管理员','拥有所有的权限'),
('2','表白内容管理员','拥有部分权限'),
('3','回复内容管理员','拥有部分权限'),
('4','网站问题管理员','拥有部分权限'),
('5','用户管理管理员','拥有部分权限123'),
('6','系统消息管理员','拥有部分权限');
DROP TABLE IF EXISTS  `tb_role_privilege`;
CREATE TABLE `tb_role_privilege` (
  `RoleId` int(11) NOT NULL COMMENT '角色编号',
  `PrivilegeId` int(11) NOT NULL COMMENT '权限编号',
  PRIMARY KEY (`PrivilegeId`,`RoleId`),
  KEY `role_Id` (`RoleId`),
  KEY `privilegeId` (`PrivilegeId`) USING BTREE,
  CONSTRAINT `privilege_Id` FOREIGN KEY (`PrivilegeId`) REFERENCES `tb_privilege` (`Id`),
  CONSTRAINT `role_Id` FOREIGN KEY (`RoleId`) REFERENCES `tb_role` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into `tb_role_privilege`(`RoleId`,`PrivilegeId`) values
('1','1'),
('1','2'),
('1','3'),
('1','4'),
('1','5'),
('1','6'),
('1','7'),
('1','8'),
('1','9'),
('1','10'),
('1','11'),
('1','12'),
('1','13'),
('1','14'),
('1','15'),
('1','16'),
('1','17'),
('1','18'),
('1','19'),
('1','20'),
('1','21'),
('1','22'),
('1','23'),
('1','24'),
('1','25'),
('1','26'),
('1','27'),
('1','28'),
('1','29'),
('1','30'),
('1','31'),
('1','32'),
('1','33'),
('1','34'),
('2','10'),
('2','11'),
('2','14'),
('2','15'),
('2','18'),
('2','19'),
('3','10'),
('3','12'),
('3','16'),
('3','17'),
('3','20'),
('4','22'),
('4','23'),
('4','24'),
('5','1'),
('5','3'),
('5','4'),
('5','5'),
('5','13'),
('6','25');
SET FOREIGN_KEY_CHECKS = 1;

